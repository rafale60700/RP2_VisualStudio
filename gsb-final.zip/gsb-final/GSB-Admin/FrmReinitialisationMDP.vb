﻿Imports MySql.Data.MySqlClient
Imports System.Security.Cryptography
Imports System.Text

Public Class FrmReinitialisationMDP

    Private Sub FrmReinitialisationMDP_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtNouvMDP.UseSystemPasswordChar = True
        txtConfirmMDP.UseSystemPasswordChar = True

        ChargerUtilisateurs()
    End Sub

    Private Sub ChargerUtilisateurs()
        Try
            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Dim sql As String =
                    "SELECT id, login " &
                    "FROM utilisateur " &
                    "ORDER BY login"

                Dim cmd As New MySqlCommand(sql, conn)
                Dim adapter As New MySqlDataAdapter(cmd)
                Dim table As New DataTable()
                adapter.Fill(table)

                cboUtilisateur.DataSource = table
                cboUtilisateur.DisplayMember = "login"
                cboUtilisateur.ValueMember = "id"
                cboUtilisateur.SelectedIndex = -1
            End Using

        Catch ex As Exception
            MessageBox.Show("Erreur lors du chargement des utilisateurs : " & ex.Message,
                            "Erreur",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function HasherMotDePasse(motDePasse As String) As String
        Using sha256 As SHA256 = SHA256.Create()
            Dim bytes As Byte() = Encoding.UTF8.GetBytes(motDePasse)
            Dim hash As Byte() = sha256.ComputeHash(bytes)

            Dim sb As New StringBuilder()
            For Each b As Byte In hash
                sb.Append(b.ToString("x2"))
            Next

            Return sb.ToString()
        End Using
    End Function

    Private Sub btnReinitMDP_Click(sender As Object, e As EventArgs) Handles btnReinitMDP.Click
        If cboUtilisateur.SelectedIndex = -1 Then
            MessageBox.Show("Veuillez sélectionner un utilisateur.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Exit Sub
        End If

        If txtNouvMDP.Text.Trim() = "" Or txtConfirmMDP.Text.Trim() = "" Then
            MessageBox.Show("Veuillez remplir tous les champs.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Exit Sub
        End If

        If txtNouvMDP.Text <> txtConfirmMDP.Text Then
            MessageBox.Show("Les mots de passe ne correspondent pas.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Exit Sub
        End If

        Try
            Dim idUtilisateur As String = cboUtilisateur.SelectedValue.ToString()
            Dim nouveauMdpHash As String = HasherMotDePasse(txtNouvMDP.Text.Trim())

            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Dim sql As String =
                    "UPDATE utilisateur " &
                    "SET mdp = @mdp " &
                    "WHERE id = @id"

                Dim cmd As New MySqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@mdp", nouveauMdpHash)
                cmd.Parameters.AddWithValue("@id", idUtilisateur)

                Dim nbLignes As Integer = cmd.ExecuteNonQuery()

                If nbLignes > 0 Then
                    MessageBox.Show("Le mot de passe a bien été réinitialisé.",
                                    "Succès",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                    txtNouvMDP.Clear()
                    txtConfirmMDP.Clear()
                    cboUtilisateur.SelectedIndex = -1
                Else
                    MessageBox.Show("Aucune modification n'a été effectuée.",
                                    "Information",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)
                End If
            End Using

        Catch ex As Exception
            MessageBox.Show("Erreur lors de la réinitialisation : " & ex.Message,
                            "Erreur",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnAnnuler_Click(sender As Object, e As EventArgs) Handles btnAnnuler.Click
        Me.Close()
    End Sub

    Private Sub btnRetour_Click(sender As Object, e As EventArgs) Handles btnRetour.Click
        Me.Close()
    End Sub


End Class