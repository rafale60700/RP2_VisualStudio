' ============================================================
' FrmListeUtilisateurs.vb — Liste des utilisateurs
' GSB-Admin — BTS SIO
' ============================================================

Imports System.Windows.Forms
Imports System.Drawing
Imports MySql.Data.MySqlClient

Public Class FrmListeUtilisateurs
    Inherits Form

    ' ── Déclaration des contrôles ────────────────────────────
    Private pnlBandeau          As Panel
    Private lblTitre            As Label
    Private lblSousTitre        As Label
    Private tabControl          As TabControl
    Private tabVisiteurs        As TabPage
    Private tabComptables       As TabPage
    Private dgvVisiteurs        As DataGridView
    Private dgvComptables       As DataGridView
    Private lblNbVisiteurs      As Label
    Private lblNbComptables     As Label
    Private WithEvents btnRetour As Button
    Private WithEvents btnActualiser As Button
    Private pnlBas              As Panel

    ' ── Constructeur ─────────────────────────────────────────
    Public Sub New()
        InitializeComponent()
    End Sub

    ' ── Initialisation visuelle ───────────────────────────────
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlBandeau = New System.Windows.Forms.Panel()
        Me.lblTitre = New System.Windows.Forms.Label()
        Me.lblSousTitre = New System.Windows.Forms.Label()
        Me.tabControl = New System.Windows.Forms.TabControl()
        Me.tabVisiteurs = New System.Windows.Forms.TabPage()
        Me.lblNbVisiteurs = New System.Windows.Forms.Label()
        Me.dgvVisiteurs = New System.Windows.Forms.DataGridView()
        Me.tabComptables = New System.Windows.Forms.TabPage()
        Me.lblNbComptables = New System.Windows.Forms.Label()
        Me.dgvComptables = New System.Windows.Forms.DataGridView()
        Me.pnlBas = New System.Windows.Forms.Panel()
        Me.btnActualiser = New System.Windows.Forms.Button()
        Me.btnRetour = New System.Windows.Forms.Button()
        Me.pnlBandeau.SuspendLayout()
        Me.tabControl.SuspendLayout()
        Me.tabVisiteurs.SuspendLayout()
        CType(Me.dgvVisiteurs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabComptables.SuspendLayout()
        CType(Me.dgvComptables, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlBas.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBandeau
        '
        Me.pnlBandeau.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.pnlBandeau.Controls.Add(Me.lblTitre)
        Me.pnlBandeau.Controls.Add(Me.lblSousTitre)
        Me.pnlBandeau.Location = New System.Drawing.Point(0, 0)
        Me.pnlBandeau.Name = "pnlBandeau"
        Me.pnlBandeau.Size = New System.Drawing.Size(900, 80)
        Me.pnlBandeau.TabIndex = 0
        '
        'lblTitre
        '
        Me.lblTitre.AutoSize = True
        Me.lblTitre.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitre.ForeColor = System.Drawing.Color.White
        Me.lblTitre.Location = New System.Drawing.Point(30, 15)
        Me.lblTitre.Name = "lblTitre"
        Me.lblTitre.Size = New System.Drawing.Size(224, 30)
        Me.lblTitre.TabIndex = 0
        Me.lblTitre.Text = "Liste des utilisateurs"
        '
        'lblSousTitre
        '
        Me.lblSousTitre.AutoSize = True
        Me.lblSousTitre.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblSousTitre.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblSousTitre.Location = New System.Drawing.Point(32, 48)
        Me.lblSousTitre.Name = "lblSousTitre"
        Me.lblSousTitre.Size = New System.Drawing.Size(241, 15)
        Me.lblSousTitre.TabIndex = 1
        Me.lblSousTitre.Text = "Visiteurs et comptables enregistrés dans GSB"
        '
        'tabControl
        '
        Me.tabControl.Controls.Add(Me.tabVisiteurs)
        Me.tabControl.Controls.Add(Me.tabComptables)
        Me.tabControl.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.tabControl.Location = New System.Drawing.Point(20, 100)
        Me.tabControl.Name = "tabControl"
        Me.tabControl.SelectedIndex = 0
        Me.tabControl.Size = New System.Drawing.Size(860, 440)
        Me.tabControl.TabIndex = 1
        '
        'tabVisiteurs
        '
        Me.tabVisiteurs.BackColor = System.Drawing.Color.White
        Me.tabVisiteurs.Controls.Add(Me.lblNbVisiteurs)
        Me.tabVisiteurs.Controls.Add(Me.dgvVisiteurs)
        Me.tabVisiteurs.Location = New System.Drawing.Point(4, 26)
        Me.tabVisiteurs.Name = "tabVisiteurs"
        Me.tabVisiteurs.Size = New System.Drawing.Size(852, 410)
        Me.tabVisiteurs.TabIndex = 0
        Me.tabVisiteurs.Text = "  Visiteurs  "
        '
        'lblNbVisiteurs
        '
        Me.lblNbVisiteurs.AutoSize = True
        Me.lblNbVisiteurs.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNbVisiteurs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.lblNbVisiteurs.Location = New System.Drawing.Point(10, 8)
        Me.lblNbVisiteurs.Name = "lblNbVisiteurs"
        Me.lblNbVisiteurs.Size = New System.Drawing.Size(85, 15)
        Me.lblNbVisiteurs.TabIndex = 0
        Me.lblNbVisiteurs.Text = "Chargement..."
        '
        'dgvVisiteurs
        '
        Me.dgvVisiteurs.AllowUserToAddRows = False
        Me.dgvVisiteurs.AllowUserToDeleteRows = False
        Me.dgvVisiteurs.AllowUserToResizeRows = False
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.dgvVisiteurs.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle13
        Me.dgvVisiteurs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvVisiteurs.BackgroundColor = System.Drawing.Color.White
        Me.dgvVisiteurs.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Segoe UI", 9.5!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvVisiteurs.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.dgvVisiteurs.ColumnHeadersHeight = 36
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvVisiteurs.DefaultCellStyle = DataGridViewCellStyle15
        Me.dgvVisiteurs.EnableHeadersVisualStyles = False
        Me.dgvVisiteurs.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.dgvVisiteurs.Location = New System.Drawing.Point(5, 30)
        Me.dgvVisiteurs.MultiSelect = False
        Me.dgvVisiteurs.Name = "dgvVisiteurs"
        Me.dgvVisiteurs.ReadOnly = True
        Me.dgvVisiteurs.RowHeadersVisible = False
        Me.dgvVisiteurs.RowTemplate.Height = 30
        Me.dgvVisiteurs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvVisiteurs.Size = New System.Drawing.Size(838, 370)
        Me.dgvVisiteurs.TabIndex = 1
        '
        'tabComptables
        '
        Me.tabComptables.BackColor = System.Drawing.Color.White
        Me.tabComptables.Controls.Add(Me.lblNbComptables)
        Me.tabComptables.Controls.Add(Me.dgvComptables)
        Me.tabComptables.Location = New System.Drawing.Point(4, 26)
        Me.tabComptables.Name = "tabComptables"
        Me.tabComptables.Size = New System.Drawing.Size(852, 410)
        Me.tabComptables.TabIndex = 1
        Me.tabComptables.Text = "  Comptables  "
        '
        'lblNbComptables
        '
        Me.lblNbComptables.AutoSize = True
        Me.lblNbComptables.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNbComptables.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.lblNbComptables.Location = New System.Drawing.Point(10, 8)
        Me.lblNbComptables.Name = "lblNbComptables"
        Me.lblNbComptables.Size = New System.Drawing.Size(85, 15)
        Me.lblNbComptables.TabIndex = 0
        Me.lblNbComptables.Text = "Chargement..."
        '
        'dgvComptables
        '
        Me.dgvComptables.AllowUserToAddRows = False
        Me.dgvComptables.AllowUserToDeleteRows = False
        Me.dgvComptables.AllowUserToResizeRows = False
        DataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.dgvComptables.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle16
        Me.dgvComptables.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvComptables.BackgroundColor = System.Drawing.Color.White
        Me.dgvComptables.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Segoe UI", 9.5!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle17.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvComptables.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle17
        Me.dgvComptables.ColumnHeadersHeight = 36
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvComptables.DefaultCellStyle = DataGridViewCellStyle18
        Me.dgvComptables.EnableHeadersVisualStyles = False
        Me.dgvComptables.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.dgvComptables.Location = New System.Drawing.Point(5, 30)
        Me.dgvComptables.MultiSelect = False
        Me.dgvComptables.Name = "dgvComptables"
        Me.dgvComptables.ReadOnly = True
        Me.dgvComptables.RowHeadersVisible = False
        Me.dgvComptables.RowTemplate.Height = 30
        Me.dgvComptables.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvComptables.Size = New System.Drawing.Size(838, 370)
        Me.dgvComptables.TabIndex = 1
        '
        'pnlBas
        '
        Me.pnlBas.BackColor = System.Drawing.Color.White
        Me.pnlBas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlBas.Controls.Add(Me.btnActualiser)
        Me.pnlBas.Controls.Add(Me.btnRetour)
        Me.pnlBas.Location = New System.Drawing.Point(20, 550)
        Me.pnlBas.Name = "pnlBas"
        Me.pnlBas.Size = New System.Drawing.Size(860, 55)
        Me.pnlBas.TabIndex = 2
        '
        'btnActualiser
        '
        Me.btnActualiser.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnActualiser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnActualiser.FlatAppearance.BorderSize = 0
        Me.btnActualiser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnActualiser.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnActualiser.ForeColor = System.Drawing.Color.White
        Me.btnActualiser.Location = New System.Drawing.Point(15, 10)
        Me.btnActualiser.Name = "btnActualiser"
        Me.btnActualiser.Size = New System.Drawing.Size(130, 36)
        Me.btnActualiser.TabIndex = 0
        Me.btnActualiser.Text = "Actualiser"
        Me.btnActualiser.UseVisualStyleBackColor = False
        '
        'btnRetour
        '
        Me.btnRetour.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.btnRetour.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRetour.FlatAppearance.BorderSize = 0
        Me.btnRetour.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRetour.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnRetour.ForeColor = System.Drawing.Color.White
        Me.btnRetour.Location = New System.Drawing.Point(685, 10)
        Me.btnRetour.Name = "btnRetour"
        Me.btnRetour.Size = New System.Drawing.Size(160, 36)
        Me.btnRetour.TabIndex = 1
        Me.btnRetour.Text = "← Retour au menu"
        Me.btnRetour.UseVisualStyleBackColor = False
        '
        'FrmListeUtilisateurs
        '
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(899, 621)
        Me.Controls.Add(Me.pnlBandeau)
        Me.Controls.Add(Me.tabControl)
        Me.Controls.Add(Me.pnlBas)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrmListeUtilisateurs"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GSB-Admin — Liste des utilisateurs"
        Me.pnlBandeau.ResumeLayout(False)
        Me.pnlBandeau.PerformLayout()
        Me.tabControl.ResumeLayout(False)
        Me.tabVisiteurs.ResumeLayout(False)
        Me.tabVisiteurs.PerformLayout()
        CType(Me.dgvVisiteurs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabComptables.ResumeLayout(False)
        Me.tabComptables.PerformLayout()
        CType(Me.dgvComptables, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlBas.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    ' ── Chargement du formulaire ──────────────────────────────
    Private Sub FrmListeUtilisateurs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ChargerVisiteurs()
        ChargerComptables()
    End Sub

    ' ── Charger la liste des visiteurs ───────────────────────
    Private Sub ChargerVisiteurs()
        Try
            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Dim sql As String =
                    "SELECT u.id AS 'ID', " &
                    "u.nom AS 'Nom', " &
                    "u.prenom AS 'Prénom', " &
                    "u.login AS 'Login', " &
                    "u.ville AS 'Ville', " &
                    "u.codePostal AS 'Code postal', " &
                    "u.adresseRue AS 'Adresse', " &
                    "DATE_FORMAT(u.dateEmbauche, '%d/%m/%Y') AS 'Date d''embauche' " &
                    "FROM utilisateur u " &
                    "INNER JOIN visiteur v ON v.id = u.id " &
                    "ORDER BY u.nom, u.prenom"

                Dim cmd     As New MySqlCommand(sql, conn)
                Dim adapter As New MySqlDataAdapter(cmd)
                Dim table   As New DataTable()
                adapter.Fill(table)

                dgvVisiteurs.DataSource = table
                lblNbVisiteurs.Text = table.Rows.Count & " visiteur(s) enregistré(s)"
            End Using
        Catch ex As Exception
            MessageBox.Show("Erreur lors du chargement des visiteurs :" & vbCrLf & ex.Message,
                            "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' ── Charger la liste des comptables ──────────────────────
    Private Sub ChargerComptables()
        Try
            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Dim sql As String =
                    "SELECT u.id AS 'ID', " &
                    "u.nom AS 'Nom', " &
                    "u.prenom AS 'Prénom', " &
                    "u.login AS 'Login', " &
                    "u.ville AS 'Ville', " &
                    "u.codePostal AS 'Code postal', " &
                    "u.adresseRue AS 'Adresse', " &
                    "DATE_FORMAT(u.dateEmbauche, '%d/%m/%Y') AS 'Date d''embauche', " &
                    "c.nbFichesRefusees AS 'Fiches refusées' " &
                    "FROM utilisateur u " &
                    "INNER JOIN comptable c ON c.id = u.id " &
                    "ORDER BY u.nom, u.prenom"

                Dim cmd     As New MySqlCommand(sql, conn)
                Dim adapter As New MySqlDataAdapter(cmd)
                Dim table   As New DataTable()
                adapter.Fill(table)

                dgvComptables.DataSource = table
                lblNbComptables.Text = table.Rows.Count & " comptable(s) enregistré(s)"
            End Using
        Catch ex As Exception
            MessageBox.Show("Erreur lors du chargement des comptables :" & vbCrLf & ex.Message,
                            "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' ── Bouton Actualiser ─────────────────────────────────────
    Private Sub btnActualiser_Click(sender As Object, e As EventArgs) Handles btnActualiser.Click
        ChargerVisiteurs()
        ChargerComptables()
    End Sub

    ' ── Bouton Retour ─────────────────────────────────────────
    Private Sub btnRetour_Click(sender As Object, e As EventArgs) Handles btnRetour.Click
        Me.Close()
    End Sub

End Class
