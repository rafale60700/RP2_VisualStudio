' ============================================================
' GestionnaireUtilisateurs.vb — Collection + association POO
' ============================================================
' Association : GestionnaireUtilisateurs → List(Of Utilisateur)
' ============================================================

Imports MySql.Data.MySqlClient

''' <summary>
''' Charge et expose la collection des utilisateurs GSB.
''' Association avec Utilisateur : 1 gestionnaire → 0..* utilisateurs.
''' </summary>
Public Class GestionnaireUtilisateurs

    ' ── Collection (List(Of Utilisateur)) ────────────────────
    Private _liste As New List(Of Utilisateur)

    Public ReadOnly Property Liste As List(Of Utilisateur)
        Get
            Return _liste
        End Get
    End Property

    ' ── Chargement depuis la BDD ─────────────────────────────
    Public Sub Charger()
        _liste.Clear()

        Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()

            ' Visiteurs
            Dim sqlV As String =
                "SELECT u.id, u.nom, u.prenom, u.login, u.adresseRue, " &
                "u.codePostal, u.ville, u.dateEmbauche " &
                "FROM utilisateur u INNER JOIN visiteur v ON v.id = u.id " &
                "ORDER BY u.nom, u.prenom"

            Using cmd As New MySqlCommand(sqlV, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        _liste.Add(New Visiteur(
                            reader("id").ToString(), reader("nom").ToString(),
                            reader("prenom").ToString(), reader("login").ToString(),
                            reader("adresseRue").ToString(), reader("codePostal").ToString(),
                            reader("ville").ToString(),
                            Convert.ToDateTime(reader("dateEmbauche"))))
                    End While
                End Using
            End Using

            ' Comptables
            Dim sqlC As String =
                "SELECT u.id, u.nom, u.prenom, u.login, u.adresseRue, " &
                "u.codePostal, u.ville, u.dateEmbauche, c.nbFichesRefusees " &
                "FROM utilisateur u INNER JOIN comptable c ON c.id = u.id " &
                "ORDER BY u.nom, u.prenom"

            Using cmd As New MySqlCommand(sqlC, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        _liste.Add(New Comptable(
                            reader("id").ToString(), reader("nom").ToString(),
                            reader("prenom").ToString(), reader("login").ToString(),
                            reader("adresseRue").ToString(), reader("codePostal").ToString(),
                            reader("ville").ToString(),
                            Convert.ToDateTime(reader("dateEmbauche")),
                            Convert.ToInt32(reader("nbFichesRefusees"))))
                    End While
                End Using
            End Using

        End Using
    End Sub

    ' ── Filtres ───────────────────────────────────────────────
    Public Function GetVisiteurs() As List(Of Visiteur)
        Return New List(Of Visiteur)(_liste.OfType(Of Visiteur)())
    End Function

    Public Function GetComptables() As List(Of Comptable)
        Return New List(Of Comptable)(_liste.OfType(Of Comptable)())
    End Function

    ''' <summary>Recherche par nom, prénom ou login (insensible à la casse).</summary>
    Public Function Rechercher(texte As String) As List(Of Utilisateur)
        Dim t As String = texte.ToLower()
        Return _liste.Where(Function(u)
            Return u.Nom.ToLower().Contains(t) OrElse
                   u.Prenom.ToLower().Contains(t) OrElse
                   u.Login.ToLower().Contains(t)
        End Function).ToList()
    End Function

End Class
