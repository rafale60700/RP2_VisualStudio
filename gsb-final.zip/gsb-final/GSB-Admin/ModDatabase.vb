Imports MySql.Data.MySqlClient

Module ModDatabase

    ' Retourne une nouvelle connexion ouverte
    ' À fermer (Using) après chaque utilisation
    Public Function NouvelleConnexion() As MySqlConnection
        Dim conn As New MySqlConnection(ModConfig.DbConnectionString)
        conn.Open()
        Return conn
    End Function

End Module
