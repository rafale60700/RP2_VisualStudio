﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCreerUtilisateur
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlMenu = New System.Windows.Forms.Panel()
        Me.gbTypeUtil = New System.Windows.Forms.GroupBox()
        Me.rdoVisiteur = New System.Windows.Forms.RadioButton()
        Me.rdoComptable = New System.Windows.Forms.RadioButton()
        Me.dtpDateEmbauche = New System.Windows.Forms.DateTimePicker()
        Me.lblDateEmbauche = New System.Windows.Forms.Label()
        Me.txtCodePostal = New System.Windows.Forms.TextBox()
        Me.lblCodePostal = New System.Windows.Forms.Label()
        Me.txtVille = New System.Windows.Forms.TextBox()
        Me.lblVille = New System.Windows.Forms.Label()
        Me.txtAdresse = New System.Windows.Forms.TextBox()
        Me.lblAdresse = New System.Windows.Forms.Label()
        Me.txtNom = New System.Windows.Forms.TextBox()
        Me.txtPrenom = New System.Windows.Forms.TextBox()
        Me.txtLogin = New System.Windows.Forms.TextBox()
        Me.lblLogin = New System.Windows.Forms.Label()
        Me.txtCreerMDP = New System.Windows.Forms.TextBox()
        Me.btnAnnuler = New System.Windows.Forms.Button()
        Me.btnCreerCompte = New System.Windows.Forms.Button()
        Me.lblCreerMDP = New System.Windows.Forms.Label()
        Me.lblNouvMDP = New System.Windows.Forms.Label()
        Me.lblNomUtil = New System.Windows.Forms.Label()
        Me.pnlBandeau = New System.Windows.Forms.Panel()
        Me.lblTitre = New System.Windows.Forms.Label()
        Me.lblSousTitre = New System.Windows.Forms.Label()
        Me.btnRetour = New System.Windows.Forms.Button()
        Me.pnlMenu.SuspendLayout()
        Me.gbTypeUtil.SuspendLayout()
        Me.pnlBandeau.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlMenu
        '
        Me.pnlMenu.BackColor = System.Drawing.Color.White
        Me.pnlMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlMenu.Controls.Add(Me.gbTypeUtil)
        Me.pnlMenu.Controls.Add(Me.dtpDateEmbauche)
        Me.pnlMenu.Controls.Add(Me.lblDateEmbauche)
        Me.pnlMenu.Controls.Add(Me.txtCodePostal)
        Me.pnlMenu.Controls.Add(Me.lblCodePostal)
        Me.pnlMenu.Controls.Add(Me.txtVille)
        Me.pnlMenu.Controls.Add(Me.lblVille)
        Me.pnlMenu.Controls.Add(Me.txtAdresse)
        Me.pnlMenu.Controls.Add(Me.lblAdresse)
        Me.pnlMenu.Controls.Add(Me.txtNom)
        Me.pnlMenu.Controls.Add(Me.txtPrenom)
        Me.pnlMenu.Controls.Add(Me.txtLogin)
        Me.pnlMenu.Controls.Add(Me.lblLogin)
        Me.pnlMenu.Controls.Add(Me.txtCreerMDP)
        Me.pnlMenu.Controls.Add(Me.btnAnnuler)
        Me.pnlMenu.Controls.Add(Me.btnCreerCompte)
        Me.pnlMenu.Controls.Add(Me.lblCreerMDP)
        Me.pnlMenu.Controls.Add(Me.lblNouvMDP)
        Me.pnlMenu.Controls.Add(Me.lblNomUtil)
        Me.pnlMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.pnlMenu.Location = New System.Drawing.Point(57, 155)
        Me.pnlMenu.Name = "pnlMenu"
        Me.pnlMenu.Size = New System.Drawing.Size(533, 581)
        Me.pnlMenu.TabIndex = 7
        '
        'gbTypeUtil
        '
        Me.gbTypeUtil.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.gbTypeUtil.Controls.Add(Me.rdoVisiteur)
        Me.gbTypeUtil.Controls.Add(Me.rdoComptable)
        Me.gbTypeUtil.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.gbTypeUtil.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.gbTypeUtil.Location = New System.Drawing.Point(148, 285)
        Me.gbTypeUtil.Name = "gbTypeUtil"
        Me.gbTypeUtil.Size = New System.Drawing.Size(208, 53)
        Me.gbTypeUtil.TabIndex = 28
        Me.gbTypeUtil.TabStop = False
        Me.gbTypeUtil.Text = "Type d'utilisateur"
        '
        'rdoVisiteur
        '
        Me.rdoVisiteur.AutoSize = True
        Me.rdoVisiteur.Location = New System.Drawing.Point(115, 23)
        Me.rdoVisiteur.Name = "rdoVisiteur"
        Me.rdoVisiteur.Size = New System.Drawing.Size(68, 19)
        Me.rdoVisiteur.TabIndex = 1
        Me.rdoVisiteur.TabStop = True
        Me.rdoVisiteur.Text = "Visiteur"
        Me.rdoVisiteur.UseVisualStyleBackColor = True
        '
        'rdoComptable
        '
        Me.rdoComptable.AutoSize = True
        Me.rdoComptable.Location = New System.Drawing.Point(20, 23)
        Me.rdoComptable.Name = "rdoComptable"
        Me.rdoComptable.Size = New System.Drawing.Size(85, 19)
        Me.rdoComptable.TabIndex = 0
        Me.rdoComptable.TabStop = True
        Me.rdoComptable.Text = "Comptable"
        Me.rdoComptable.UseVisualStyleBackColor = True
        '
        'dtpDateEmbauche
        '
        Me.dtpDateEmbauche.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.dtpDateEmbauche.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.dtpDateEmbauche.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveBorder
        Me.dtpDateEmbauche.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.dtpDateEmbauche.Location = New System.Drawing.Point(286, 232)
        Me.dtpDateEmbauche.Name = "dtpDateEmbauche"
        Me.dtpDateEmbauche.Size = New System.Drawing.Size(200, 25)
        Me.dtpDateEmbauche.TabIndex = 27
        '
        'lblDateEmbauche
        '
        Me.lblDateEmbauche.AutoSize = True
        Me.lblDateEmbauche.BackColor = System.Drawing.Color.Transparent
        Me.lblDateEmbauche.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblDateEmbauche.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblDateEmbauche.Location = New System.Drawing.Point(283, 201)
        Me.lblDateEmbauche.Name = "lblDateEmbauche"
        Me.lblDateEmbauche.Size = New System.Drawing.Size(112, 15)
        Me.lblDateEmbauche.TabIndex = 26
        Me.lblDateEmbauche.Text = "Date d'embauche :"
        '
        'txtCodePostal
        '
        Me.txtCodePostal.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtCodePostal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCodePostal.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtCodePostal.Location = New System.Drawing.Point(22, 232)
        Me.txtCodePostal.Name = "txtCodePostal"
        Me.txtCodePostal.Size = New System.Drawing.Size(208, 25)
        Me.txtCodePostal.TabIndex = 25
        '
        'lblCodePostal
        '
        Me.lblCodePostal.AutoSize = True
        Me.lblCodePostal.BackColor = System.Drawing.Color.Transparent
        Me.lblCodePostal.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblCodePostal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblCodePostal.Location = New System.Drawing.Point(19, 201)
        Me.lblCodePostal.Name = "lblCodePostal"
        Me.lblCodePostal.Size = New System.Drawing.Size(77, 15)
        Me.lblCodePostal.TabIndex = 24
        Me.lblCodePostal.Text = "Code postal :"
        '
        'txtVille
        '
        Me.txtVille.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtVille.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVille.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtVille.Location = New System.Drawing.Point(286, 142)
        Me.txtVille.Name = "txtVille"
        Me.txtVille.Size = New System.Drawing.Size(208, 25)
        Me.txtVille.TabIndex = 23
        '
        'lblVille
        '
        Me.lblVille.AutoSize = True
        Me.lblVille.BackColor = System.Drawing.Color.Transparent
        Me.lblVille.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblVille.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblVille.Location = New System.Drawing.Point(283, 111)
        Me.lblVille.Name = "lblVille"
        Me.lblVille.Size = New System.Drawing.Size(37, 15)
        Me.lblVille.TabIndex = 22
        Me.lblVille.Text = "Ville :"
        '
        'txtAdresse
        '
        Me.txtAdresse.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtAdresse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdresse.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtAdresse.Location = New System.Drawing.Point(22, 142)
        Me.txtAdresse.Name = "txtAdresse"
        Me.txtAdresse.Size = New System.Drawing.Size(208, 25)
        Me.txtAdresse.TabIndex = 21
        '
        'lblAdresse
        '
        Me.lblAdresse.AutoSize = True
        Me.lblAdresse.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblAdresse.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblAdresse.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblAdresse.Location = New System.Drawing.Point(19, 111)
        Me.lblAdresse.Name = "lblAdresse"
        Me.lblAdresse.Size = New System.Drawing.Size(57, 15)
        Me.lblAdresse.TabIndex = 20
        Me.lblAdresse.Text = "Adresse :"
        '
        'txtNom
        '
        Me.txtNom.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtNom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNom.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtNom.Location = New System.Drawing.Point(22, 64)
        Me.txtNom.Name = "txtNom"
        Me.txtNom.Size = New System.Drawing.Size(208, 25)
        Me.txtNom.TabIndex = 19
        '
        'txtPrenom
        '
        Me.txtPrenom.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtPrenom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPrenom.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtPrenom.Location = New System.Drawing.Point(286, 64)
        Me.txtPrenom.Name = "txtPrenom"
        Me.txtPrenom.Size = New System.Drawing.Size(208, 25)
        Me.txtPrenom.TabIndex = 18
        '
        'txtLogin
        '
        Me.txtLogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLogin.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtLogin.Location = New System.Drawing.Point(24, 386)
        Me.txtLogin.Name = "txtLogin"
        Me.txtLogin.Size = New System.Drawing.Size(208, 25)
        Me.txtLogin.TabIndex = 17
        '
        'lblLogin
        '
        Me.lblLogin.AutoSize = True
        Me.lblLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblLogin.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblLogin.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblLogin.Location = New System.Drawing.Point(21, 355)
        Me.lblLogin.Name = "lblLogin"
        Me.lblLogin.Size = New System.Drawing.Size(148, 15)
        Me.lblLogin.TabIndex = 16
        Me.lblLogin.Text = "Nom d'utilisateur (login) :"
        '
        'txtCreerMDP
        '
        Me.txtCreerMDP.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtCreerMDP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCreerMDP.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtCreerMDP.Location = New System.Drawing.Point(286, 386)
        Me.txtCreerMDP.MaxLength = 50
        Me.txtCreerMDP.Name = "txtCreerMDP"
        Me.txtCreerMDP.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtCreerMDP.Size = New System.Drawing.Size(208, 25)
        Me.txtCreerMDP.TabIndex = 13
        Me.txtCreerMDP.UseSystemPasswordChar = True
        '
        'btnAnnuler
        '
        Me.btnAnnuler.BackColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnAnnuler.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAnnuler.FlatAppearance.BorderSize = 0
        Me.btnAnnuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAnnuler.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnAnnuler.ForeColor = System.Drawing.Color.White
        Me.btnAnnuler.Location = New System.Drawing.Point(286, 451)
        Me.btnAnnuler.Name = "btnAnnuler"
        Me.btnAnnuler.Size = New System.Drawing.Size(200, 45)
        Me.btnAnnuler.TabIndex = 11
        Me.btnAnnuler.Text = "Annuler"
        Me.btnAnnuler.UseVisualStyleBackColor = False
        '
        'btnCreerCompte
        '
        Me.btnCreerCompte.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnCreerCompte.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCreerCompte.FlatAppearance.BorderSize = 0
        Me.btnCreerCompte.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCreerCompte.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnCreerCompte.ForeColor = System.Drawing.Color.White
        Me.btnCreerCompte.Location = New System.Drawing.Point(30, 451)
        Me.btnCreerCompte.Name = "btnCreerCompte"
        Me.btnCreerCompte.Size = New System.Drawing.Size(200, 45)
        Me.btnCreerCompte.TabIndex = 10
        Me.btnCreerCompte.Text = "Créer mon compte"
        Me.btnCreerCompte.UseVisualStyleBackColor = False
        '
        'lblCreerMDP
        '
        Me.lblCreerMDP.AutoSize = True
        Me.lblCreerMDP.BackColor = System.Drawing.Color.Transparent
        Me.lblCreerMDP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblCreerMDP.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblCreerMDP.Location = New System.Drawing.Point(283, 355)
        Me.lblCreerMDP.Name = "lblCreerMDP"
        Me.lblCreerMDP.Size = New System.Drawing.Size(137, 15)
        Me.lblCreerMDP.TabIndex = 8
        Me.lblCreerMDP.Text = "Créer un mot de passe :"
        '
        'lblNouvMDP
        '
        Me.lblNouvMDP.AutoSize = True
        Me.lblNouvMDP.BackColor = System.Drawing.Color.Transparent
        Me.lblNouvMDP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNouvMDP.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblNouvMDP.Location = New System.Drawing.Point(283, 33)
        Me.lblNouvMDP.Name = "lblNouvMDP"
        Me.lblNouvMDP.Size = New System.Drawing.Size(57, 15)
        Me.lblNouvMDP.TabIndex = 7
        Me.lblNouvMDP.Text = "Prénom :"
        '
        'lblNomUtil
        '
        Me.lblNomUtil.AutoSize = True
        Me.lblNomUtil.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblNomUtil.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNomUtil.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblNomUtil.Location = New System.Drawing.Point(19, 33)
        Me.lblNomUtil.Name = "lblNomUtil"
        Me.lblNomUtil.Size = New System.Drawing.Size(40, 15)
        Me.lblNomUtil.TabIndex = 6
        Me.lblNomUtil.Text = "Nom :"
        '
        'pnlBandeau
        '
        Me.pnlBandeau.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.pnlBandeau.Controls.Add(Me.lblTitre)
        Me.pnlBandeau.Controls.Add(Me.lblSousTitre)
        Me.pnlBandeau.Location = New System.Drawing.Point(-222, -1)
        Me.pnlBandeau.Name = "pnlBandeau"
        Me.pnlBandeau.Size = New System.Drawing.Size(1127, 99)
        Me.pnlBandeau.TabIndex = 8
        '
        'lblTitre
        '
        Me.lblTitre.AutoSize = True
        Me.lblTitre.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitre.ForeColor = System.Drawing.Color.White
        Me.lblTitre.Location = New System.Drawing.Point(232, 20)
        Me.lblTitre.Name = "lblTitre"
        Me.lblTitre.Size = New System.Drawing.Size(212, 30)
        Me.lblTitre.TabIndex = 0
        Me.lblTitre.Text = "Créer un utilisateur"
        '
        'lblSousTitre
        '
        Me.lblSousTitre.AutoSize = True
        Me.lblSousTitre.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblSousTitre.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblSousTitre.Location = New System.Drawing.Point(234, 60)
        Me.lblSousTitre.Name = "lblSousTitre"
        Me.lblSousTitre.Size = New System.Drawing.Size(272, 15)
        Me.lblSousTitre.TabIndex = 1
        Me.lblSousTitre.Text = "Saisissez vos informations pour créer un utilisateur"
        '
        'btnRetour
        '
        Me.btnRetour.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.btnRetour.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRetour.FlatAppearance.BorderSize = 0
        Me.btnRetour.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRetour.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnRetour.ForeColor = System.Drawing.Color.White
        Me.btnRetour.Location = New System.Drawing.Point(489, 104)
        Me.btnRetour.Name = "btnRetour"
        Me.btnRetour.Size = New System.Drawing.Size(150, 36)
        Me.btnRetour.TabIndex = 29
        Me.btnRetour.Text = "← Retour au menu"
        Me.btnRetour.UseVisualStyleBackColor = False
        '
        'FrmCreerUtilisateur
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(652, 761)
        Me.Controls.Add(Me.btnRetour)
        Me.Controls.Add(Me.pnlBandeau)
        Me.Controls.Add(Me.pnlMenu)
        Me.Name = "FrmCreerUtilisateur"
        Me.Text = "FrmCreerUtilisateur"
        Me.pnlMenu.ResumeLayout(False)
        Me.pnlMenu.PerformLayout()
        Me.gbTypeUtil.ResumeLayout(False)
        Me.gbTypeUtil.PerformLayout()
        Me.pnlBandeau.ResumeLayout(False)
        Me.pnlBandeau.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents pnlMenu As Panel
    Private WithEvents txtCreerMDP As TextBox
    Private WithEvents btnAnnuler As Button
    Private WithEvents btnCreerCompte As Button
    Friend WithEvents lblCreerMDP As Label
    Friend WithEvents lblNouvMDP As Label
    Friend WithEvents lblNomUtil As Label
    Private WithEvents pnlBandeau As Panel
    Private WithEvents lblTitre As Label
    Private WithEvents lblSousTitre As Label
    Friend WithEvents lblLogin As Label
    Friend WithEvents txtNom As TextBox
    Friend WithEvents txtPrenom As TextBox
    Friend WithEvents txtLogin As TextBox
    Friend WithEvents txtCodePostal As TextBox
    Friend WithEvents lblCodePostal As Label
    Friend WithEvents txtVille As TextBox
    Friend WithEvents lblVille As Label
    Friend WithEvents txtAdresse As TextBox
    Friend WithEvents lblAdresse As Label
    Friend WithEvents dtpDateEmbauche As DateTimePicker
    Friend WithEvents lblDateEmbauche As Label
    Friend WithEvents gbTypeUtil As GroupBox
    Friend WithEvents rdoVisiteur As RadioButton
    Friend WithEvents rdoComptable As RadioButton
    Private WithEvents btnRetour As Button
End Class
