﻿Imports MySql.Data.MySqlClient
Imports System.Security.Cryptography
Imports System.Text

Public Class FrmCreerUtilisateur

    Private Sub FrmCreerUtilisateur_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtCreerMDP.UseSystemPasswordChar = True
        dtpDateEmbauche.Format = DateTimePickerFormat.Short
    End Sub

    Private Function HasherMotDePasse(motDePasse As String) As String
        Using sha256 As SHA256 = SHA256.Create()
            Dim bytes As Byte() = Encoding.UTF8.GetBytes(motDePasse)
            Dim hash As Byte() = sha256.ComputeHash(bytes)

            Dim sb As New StringBuilder()
            For Each b As Byte In hash
                sb.Append(b.ToString("x2"))
            Next

            Return sb.ToString()
        End Using
    End Function

    Private Function ChampsValides() As Boolean
        If txtNom.Text.Trim() = "" OrElse
           txtPrenom.Text.Trim() = "" OrElse
           txtAdresse.Text.Trim() = "" OrElse
           txtVille.Text.Trim() = "" OrElse
           txtCodePostal.Text.Trim() = "" OrElse
           txtLogin.Text.Trim() = "" OrElse
           txtCreerMDP.Text.Trim() = "" Then

            MessageBox.Show("Veuillez remplir tous les champs.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Return False
        End If

        If Not rdoVisiteur.Checked And Not rdoComptable.Checked Then
            MessageBox.Show("Veuillez sélectionner un type d'utilisateur.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Return False
        End If

        If txtCodePostal.Text.Trim().Length <> 5 OrElse Not IsNumeric(txtCodePostal.Text.Trim()) Then
            MessageBox.Show("Le code postal doit contenir 5 chiffres.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Return False
        End If

        If txtLogin.Text.Trim().Length > 20 Then
            MessageBox.Show("Le login ne doit pas dépasser 20 caractères.",
                            "Attention",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function

    Private Function GenererIdUnique(conn As MySqlConnection, transaction As MySqlTransaction) As String
        Dim aleatoire As New Random()
        Dim idGenere As String = ""
        Dim existe As Integer = 0

        Do
            Dim lettre As Char = Chr(aleatoire.Next(97, 123))
            Dim nombre As Integer = aleatoire.Next(100, 999)
            idGenere = lettre & nombre.ToString()

            Dim sql As String = "SELECT COUNT(*) FROM utilisateur WHERE id = @id"
            Using cmd As New MySqlCommand(sql, conn, transaction)
                cmd.Parameters.AddWithValue("@id", idGenere)
                existe = Convert.ToInt32(cmd.ExecuteScalar())
            End Using

        Loop While existe > 0

        Return idGenere
    End Function

    Private Sub btnCreerCompte_Click(sender As Object, e As EventArgs) Handles btnCreerCompte.Click
        If Not ChampsValides() Then Exit Sub

        Dim nom As String = txtNom.Text.Trim()
        Dim prenom As String = txtPrenom.Text.Trim()
        Dim adresse As String = txtAdresse.Text.Trim()
        Dim ville As String = txtVille.Text.Trim()
        Dim codePostal As String = txtCodePostal.Text.Trim()
        Dim login As String = txtLogin.Text.Trim()
        Dim mdpHash As String = HasherMotDePasse(txtCreerMDP.Text.Trim())
        Dim dateEmbauche As Date = dtpDateEmbauche.Value.Date

        Dim typeUtilisateur As String = ""
        If rdoVisiteur.Checked Then
            typeUtilisateur = "Visiteur"
        ElseIf rdoComptable.Checked Then
            typeUtilisateur = "Comptable"
        End If

        Try
            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Using transaction As MySqlTransaction = conn.BeginTransaction()

                    Try
                        Dim sqlVerifLogin As String = "SELECT COUNT(*) FROM utilisateur WHERE login = @login"
                        Using cmdVerifLogin As New MySqlCommand(sqlVerifLogin, conn, transaction)
                            cmdVerifLogin.Parameters.AddWithValue("@login", login)
                            Dim nbLogin As Integer = Convert.ToInt32(cmdVerifLogin.ExecuteScalar())

                            If nbLogin > 0 Then
                                MessageBox.Show("Ce login existe déjà.",
                                                "Attention",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Warning)
                                transaction.Rollback()
                                Exit Sub
                            End If
                        End Using

                        Dim idUtilisateur As String = GenererIdUnique(conn, transaction)

                        Dim sqlUtilisateur As String =
                            "INSERT INTO utilisateur (id, nom, prenom, login, mdp, adresseRue, codePostal, ville, dateEmbauche) " &
                            "VALUES (@id, @nom, @prenom, @login, @mdp, @adresseRue, @codePostal, @ville, @dateEmbauche)"

                        Using cmdUtilisateur As New MySqlCommand(sqlUtilisateur, conn, transaction)
                            cmdUtilisateur.Parameters.AddWithValue("@id", idUtilisateur)
                            cmdUtilisateur.Parameters.AddWithValue("@nom", nom)
                            cmdUtilisateur.Parameters.AddWithValue("@prenom", prenom)
                            cmdUtilisateur.Parameters.AddWithValue("@login", login)
                            cmdUtilisateur.Parameters.AddWithValue("@mdp", mdpHash)
                            cmdUtilisateur.Parameters.AddWithValue("@adresseRue", adresse)
                            cmdUtilisateur.Parameters.AddWithValue("@codePostal", codePostal)
                            cmdUtilisateur.Parameters.AddWithValue("@ville", ville)
                            cmdUtilisateur.Parameters.AddWithValue("@dateEmbauche", dateEmbauche)

                            cmdUtilisateur.ExecuteNonQuery()
                        End Using

                        If typeUtilisateur = "Visiteur" Then
                            Dim sqlVisiteur As String = "INSERT INTO visiteur (id) VALUES (@id)"
                            Using cmdVisiteur As New MySqlCommand(sqlVisiteur, conn, transaction)
                                cmdVisiteur.Parameters.AddWithValue("@id", idUtilisateur)
                                cmdVisiteur.ExecuteNonQuery()
                            End Using

                        ElseIf typeUtilisateur = "Comptable" Then
                            Dim sqlComptable As String = "INSERT INTO comptable (id, nbFichesRefusees) VALUES (@id, 0)"
                            Using cmdComptable As New MySqlCommand(sqlComptable, conn, transaction)
                                cmdComptable.Parameters.AddWithValue("@id", idUtilisateur)
                                cmdComptable.ExecuteNonQuery()
                            End Using
                        End If

                        transaction.Commit()

                        MessageBox.Show("L'utilisateur a bien été créé." & vbCrLf & "Identifiant généré : " & idUtilisateur,
                                        "Succès",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information)

                        ViderChamps()

                    Catch ex As Exception
                        transaction.Rollback()
                        Throw
                    End Try
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Erreur lors de la création de l'utilisateur :" & vbCrLf & ex.Message,
                            "Erreur",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ViderChamps()
        txtNom.Clear()
        txtPrenom.Clear()
        txtAdresse.Clear()
        txtVille.Clear()
        txtCodePostal.Clear()
        txtLogin.Clear()
        txtCreerMDP.Clear()
        rdoVisiteur.Checked = False
        rdoComptable.Checked = False
        dtpDateEmbauche.Value = Date.Today
        txtNom.Focus()
    End Sub

    Private Sub btnAnnuler_Click(sender As Object, e As EventArgs) Handles btnAnnuler.Click
        Me.Close()
    End Sub

    Private Sub btnRetour_Click(sender As Object, e As EventArgs) Handles btnRetour.Click
        Me.Close()
    End Sub
End Class