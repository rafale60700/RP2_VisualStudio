' ============================================================
' ModConfig.vb — Lecture du fichier gsb.ini
' GSB-Admin — BTS SIO
' ============================================================
' Le mot de passe BDD est chiffré via AES (clé dérivée du nom
' de machine) — aucune référence externe requise.
' Le mot de passe admin est stocké en hash SHA-256.
' ============================================================

Imports System.IO
Imports System.Text
Imports System.Security.Cryptography

Module ModConfig

    Public DbConnectionString As String = String.Empty
    Public AdminPasswordHash   As String = String.Empty
    Public ModeTest            As Boolean = False

    Private Const NOM_FICHIER As String = "gsb.ini"

    ' Clé AES dérivée du nom de machine (16 octets)
    Private Function CleAES() As Byte()
        Dim source As String = Environment.MachineName & "GSB-Admin-2026"
        Using sha As SHA256 = SHA256.Create()
            Dim hash() As Byte = sha.ComputeHash(Encoding.UTF8.GetBytes(source))
            ' On prend les 16 premiers octets (AES-128)
            Dim cle(15) As Byte
            Array.Copy(hash, cle, 16)
            Return cle
        End Using
    End Function

    Public Function Chiffrer(texte As String) As String
        Dim cle() As Byte = CleAES()
        Using aes As Aes = Aes.Create()
            aes.Key = cle
            aes.GenerateIV()
            Using ms As New MemoryStream()
                ' Écrire l'IV en tête (16 octets)
                ms.Write(aes.IV, 0, aes.IV.Length)
                Using cs As New CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write)
                    Dim octets() As Byte = Encoding.UTF8.GetBytes(texte)
                    cs.Write(octets, 0, octets.Length)
                    cs.FlushFinalBlock()
                End Using
                Return Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
    End Function

    Public Function Dechiffrer(base64 As String) As String
        Try
            Dim cle()     As Byte = CleAES()
            Dim donnees() As Byte = Convert.FromBase64String(base64)

            Using aes As Aes = Aes.Create()
                aes.Key = cle
                ' Lire l'IV depuis les 16 premiers octets
                Dim iv(15) As Byte
                Array.Copy(donnees, 0, iv, 0, 16)
                aes.IV = iv

                Using ms As New MemoryStream(donnees, 16, donnees.Length - 16)
                    Using cs As New CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read)
                        Using sr As New StreamReader(cs, Encoding.UTF8)
                            Return sr.ReadToEnd()
                        End Using
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Throw New Exception(
                "Impossible de déchiffrer password_enc." & vbCrLf &
                "Ce gsb.ini a peut-être été créé sur une autre machine." & vbCrLf &
                "Solution : remplacez 'password_enc' par 'password = <mdp_clair>'." & vbCrLf &
                ex.Message)
        End Try
    End Function

    Private Sub ChiffrerEtReecrirebIni(chemin As String, mdpClair As String)
        Try
            Dim enc      As String    = Chiffrer(mdpClair)
            Dim lignes() As String    = File.ReadAllLines(chemin, Encoding.UTF8)
            Dim result   As New List(Of String)
            Dim dansDb   As Boolean   = False

            For Each ligne As String In lignes
                Dim l As String = ligne.Trim().ToLower()
                If l = "[database]" Then dansDb = True : result.Add(ligne) : Continue For
                If l.StartsWith("[") Then dansDb = False
                If dansDb AndAlso l.StartsWith("password") AndAlso Not l.StartsWith("password_enc") Then
                    result.Add("password_enc = " & enc)
                    result.Add("; Chiffré automatiquement (AES, lié à cette machine)")
                Else
                    result.Add(ligne)
                End If
            Next
            File.WriteAllLines(chemin, result.ToArray(), Encoding.UTF8)
        Catch
            ' Silencieux : on continue avec le mdp en mémoire
        End Try
    End Sub

    ' =========================================================
    ' Charger() — appeler au démarrage dans FrmConnexion_Load
    ' =========================================================
    Public Sub Charger()
        Dim chemin As String = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, NOM_FICHIER)

        If Not File.Exists(chemin) Then
            Throw New FileNotFoundException(
                "Fichier de configuration introuvable : " & chemin & vbCrLf &
                "Placez gsb.ini dans le même dossier que l'application.")
        End If

        ' ── Parsing INI ──────────────────────────────────────
        Dim section As String = String.Empty
        Dim valeurs As New Dictionary(Of String, Dictionary(Of String, String))

        For Each ligne As String In File.ReadAllLines(chemin, Encoding.UTF8)
            Dim l As String = ligne.Trim()
            If l.Length = 0 OrElse l.StartsWith(";") OrElse l.StartsWith("#") Then Continue For

            If l.StartsWith("[") AndAlso l.EndsWith("]") Then
                section = l.Substring(1, l.Length - 2).ToLower().Trim()
                If Not valeurs.ContainsKey(section) Then
                    valeurs(section) = New Dictionary(Of String, String)
                End If
                Continue For
            End If

            Dim sep As Integer = l.IndexOf("=")
            If sep > 0 AndAlso section <> String.Empty Then
                Dim cle    As String = l.Substring(0, sep).Trim().ToLower()
                Dim valeur As String = l.Substring(sep + 1).Trim()
                valeurs(section)(cle) = valeur
            End If
        Next

        ' ── Mode test ────────────────────────────────────────
        If valeurs.ContainsKey("test") AndAlso
           valeurs("test").ContainsKey("mode") AndAlso
           valeurs("test")("mode").ToLower() = "on" Then
            ModeTest = True
        End If

        ' ── Connexion MySQL ───────────────────────────────────
        If Not ModeTest Then
            Try
                Dim db As Dictionary(Of String, String) = valeurs("database")
                Dim mdp As String

                If db.ContainsKey("password_enc") Then
                    mdp = Dechiffrer(db("password_enc"))
                ElseIf db.ContainsKey("password") Then
                    mdp = db("password")
                    ChiffrerEtReecrirebIni(chemin, mdp)
                Else
                    Throw New Exception("Clé 'password' ou 'password_enc' manquante dans [database].")
                End If

                DbConnectionString = String.Format(
                    "Server={0};Port={1};Database={2};Uid={3};Pwd={4};CharSet=utf8;",
                    db("server"), db("port"), db("name"), db("user"), mdp)

            Catch ex As Exception
                Throw New Exception(
                    "Section [database] manquante ou incomplète dans gsb.ini." & vbCrLf & ex.Message)
            End Try
        End If

        ' ── Mot de passe super-admin ──────────────────────────
        Try
            AdminPasswordHash = valeurs("superadmin")("password").ToLower()
        Catch ex As Exception
            Throw New Exception(
                "Section [superadmin] manquante ou incomplète dans gsb.ini." & vbCrLf & ex.Message)
        End Try
    End Sub

    ' ── Vérification mot de passe admin ──────────────────────
    Public Function VerifierMotDePasse(motDePasseSaisi As String) As Boolean
        If ModeTest Then Return motDePasseSaisi.Trim().Length > 0
        Return String.Equals(HashSHA256(motDePasseSaisi), AdminPasswordHash,
                             StringComparison.OrdinalIgnoreCase)
    End Function

    Public Function HashSHA256(texte As String) As String
        Using sha As SHA256 = SHA256.Create()
            Dim octets() As Byte = sha.ComputeHash(Encoding.UTF8.GetBytes(texte))
            Dim sb As New StringBuilder()
            For Each b As Byte In octets : sb.Append(b.ToString("x2")) : Next
            Return sb.ToString()
        End Using
    End Function

End Module
