' ============================================================
' FrmConnexion.vb — Formulaire de connexion super-admin
' GSB-Admin — BTS SIO
' Conforme CDC AP8 : authentification par mot de passe uniquement
' ============================================================

Imports System.Windows.Forms
Imports System.Drawing

Public Class FrmConnexion
    Inherits Form

    ' ── Déclaration des contrôles ────────────────────────────
    Private WithEvents btnConnexion As Button
    Private txtMdp As TextBox
    Private lblErreur As Label
    Private lblTitre As Label
    Private lblSousTitre As Label
    Private lblMdp As Label
    Private pnlBandeau As Panel
    Private pnlFormulaire As Panel

    ' ── Constructeur ─────────────────────────────────────────
    Public Sub New()
        InitializeComponent()
    End Sub

    ' ── Initialisation visuelle ───────────────────────────────
    Private Sub InitializeComponent()

        ' --- Fenêtre principale ---
        Me.Text = "GSB-Admin — Connexion"
        Me.Size = New Size(420, 400)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.BackColor = Color.FromArgb(245, 247, 250)
        Me.Font = New Font("Segoe UI", 9.5F)

        ' --- Bandeau haut bleu foncé ---
        pnlBandeau = New Panel()
        pnlBandeau.BackColor = Color.FromArgb(30, 78, 121)
        pnlBandeau.Size = New Size(420, 110)
        pnlBandeau.Location = New Point(0, 0)

        lblTitre = New Label()
        lblTitre.Text = "GSB-Admin"
        lblTitre.ForeColor = Color.White
        lblTitre.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold)
        lblTitre.AutoSize = True
        lblTitre.Location = New Point(30, 22)

        lblSousTitre = New Label()
        lblSousTitre.Text = "Application de back-office"
        lblSousTitre.ForeColor = Color.FromArgb(180, 210, 240)
        lblSousTitre.Font = New Font("Segoe UI", 10.0F)
        lblSousTitre.AutoSize = True
        lblSousTitre.Location = New Point(32, 66)

        pnlBandeau.Controls.Add(lblTitre)
        pnlBandeau.Controls.Add(lblSousTitre)

        ' --- Panneau formulaire blanc ---
        pnlFormulaire = New Panel()
        pnlFormulaire.BackColor = Color.White
        pnlFormulaire.Size = New Size(340, 180)
        pnlFormulaire.Location = New Point(40, 140)
        pnlFormulaire.BorderStyle = BorderStyle.FixedSingle

        ' --- Label Mot de passe ---
        lblMdp = New Label()
        lblMdp.Text = "Mot de passe administrateur"
        lblMdp.ForeColor = Color.FromArgb(80, 80, 80)
        lblMdp.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)
        lblMdp.AutoSize = True
        lblMdp.Location = New Point(20, 24)

        ' --- TextBox Mot de passe ---
        txtMdp = New TextBox()
        txtMdp.Name = "txtMdp"
        txtMdp.Size = New Size(300, 28)
        txtMdp.Location = New Point(20, 46)
        txtMdp.Font = New Font("Segoe UI", 10.0F)
        txtMdp.BackColor = Color.FromArgb(245, 247, 250)
        txtMdp.BorderStyle = BorderStyle.FixedSingle
        txtMdp.PasswordChar = "*"c
        txtMdp.MaxLength = 50

        ' --- Label Erreur ---
        lblErreur = New Label()
        lblErreur.Name = "lblErreur"
        lblErreur.Text = "Mot de passe incorrect."
        lblErreur.ForeColor = Color.FromArgb(180, 30, 30)
        lblErreur.Font = New Font("Segoe UI", 9.0F)
        lblErreur.AutoSize = True
        lblErreur.Location = New Point(20, 86)
        lblErreur.Visible = False

        ' --- Bouton Connexion ---
        btnConnexion = New Button()
        btnConnexion.Name = "btnConnexion"
        btnConnexion.Text = "Se connecter"
        btnConnexion.Size = New Size(300, 40)
        btnConnexion.Location = New Point(20, 122)
        btnConnexion.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnConnexion.BackColor = Color.FromArgb(30, 78, 121)
        btnConnexion.ForeColor = Color.White
        btnConnexion.FlatStyle = FlatStyle.Flat
        btnConnexion.FlatAppearance.BorderSize = 0
        btnConnexion.Cursor = Cursors.Hand

        ' Ajout des contrôles dans le panneau
        pnlFormulaire.Controls.Add(lblMdp)
        pnlFormulaire.Controls.Add(txtMdp)
        pnlFormulaire.Controls.Add(lblErreur)
        pnlFormulaire.Controls.Add(btnConnexion)

        ' --- Pied de page ---
        Dim lblFooter As New Label()
        lblFooter.Text = "© GSB-Admin — BTS SIO"
        lblFooter.ForeColor = Color.FromArgb(160, 160, 160)
        lblFooter.Font = New Font("Segoe UI", 8.0F)
        lblFooter.AutoSize = True
        lblFooter.Location = New Point(140, 350)

        ' Ajout au formulaire
        Me.Controls.Add(pnlBandeau)
        Me.Controls.Add(pnlFormulaire)
        Me.Controls.Add(lblFooter)

        ' Touche Entrée = clic sur btnConnexion
        Me.AcceptButton = btnConnexion

    End Sub

    ' ── Chargement : lecture du fichier INI ──────────────────
    Private Sub FrmConnexion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ModConfig.Charger()
        Catch ex As Exception
            MessageBox.Show(
                ex.Message,
                "Erreur de configuration",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)
            Application.Exit()
        End Try
        txtMdp.Focus()
    End Sub

    ' ── Clic sur "Se connecter" ───────────────────────────────
    Private Sub btnConnexion_Click(sender As Object, e As EventArgs) Handles btnConnexion.Click
        Dim mdpSaisi As String = txtMdp.Text

        ' Champ vide
        If mdpSaisi.Trim() = String.Empty Then
            AfficherErreur("Veuillez saisir le mot de passe.")
            Return
        End If

        ' Vérification mot de passe via hash SHA-256
        If Not ModConfig.VerifierMotDePasse(mdpSaisi) Then
            AfficherErreur("Mot de passe incorrect.")
            Return
        End If

        ' Connexion réussie → ouvrir le menu principal
        Dim frmMenu As New FrmMenu()
        frmMenu.Show()
        Me.Hide()
    End Sub

    ' ── Affiche un message d'erreur ──────────────────────────
    Private Sub AfficherErreur(message As String)
        lblErreur.Text = message
        lblErreur.Visible = True
        txtMdp.Clear()
        txtMdp.Focus()
    End Sub

End Class