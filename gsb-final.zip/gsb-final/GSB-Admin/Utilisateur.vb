' ============================================================
' Utilisateur.vb — Classes POO (BTS SIO SLAM)
' ============================================================
' Hiérarchie :
'   Utilisateur (classe de base)
'     ├── Visiteur   (Inherits Utilisateur)
'     └── Comptable  (Inherits Utilisateur)
' ============================================================

''' <summary>Représente un utilisateur GSB (visiteur ou comptable).</summary>
Public Class Utilisateur

    Public Property Id           As String
    Public Property Nom          As String
    Public Property Prenom       As String
    Public Property Login        As String
    Public Property AdresseRue   As String
    Public Property CodePostal   As String
    Public Property Ville        As String
    Public Property DateEmbauche As Date

    Public Sub New(id As String, nom As String, prenom As String,
                   login As String, adresse As String,
                   cp As String, ville As String, dateEmb As Date)
        Me.Id           = id
        Me.Nom          = nom
        Me.Prenom       = prenom
        Me.Login        = login
        Me.AdresseRue   = adresse
        Me.CodePostal   = cp
        Me.Ville        = ville
        Me.DateEmbauche = dateEmb
    End Sub

    ''' <summary>Prénom + Nom.</summary>
    Public ReadOnly Property NomComplet As String
        Get
            Return Prenom & " " & Nom
        End Get
    End Property

    ''' <summary>Retourne le type (surcharge dans sous-classes).</summary>
    Public Overridable ReadOnly Property TypeUtilisateur As String
        Get
            Return "Utilisateur"
        End Get
    End Property

    Public Overrides Function ToString() As String
        Return "[" & TypeUtilisateur & "] " & NomComplet & " (" & Login & ")"
    End Function

End Class

' ── Visiteur ────────────────────────────────────────────────
''' <summary>Visiteur médical — hérite de Utilisateur.</summary>
Public Class Visiteur
    Inherits Utilisateur

    Public Sub New(id As String, nom As String, prenom As String,
                   login As String, adresse As String,
                   cp As String, ville As String, dateEmb As Date)
        MyBase.New(id, nom, prenom, login, adresse, cp, ville, dateEmb)
    End Sub

    Public Overrides ReadOnly Property TypeUtilisateur As String
        Get
            Return "Visiteur"
        End Get
    End Property

End Class

' ── Comptable ────────────────────────────────────────────────
''' <summary>Comptable — hérite de Utilisateur.</summary>
Public Class Comptable
    Inherits Utilisateur

    ''' <summary>Mis à jour automatiquement par le trigger MySQL.</summary>
    Public Property NbFichesRefusees As Integer

    Public Sub New(id As String, nom As String, prenom As String,
                   login As String, adresse As String,
                   cp As String, ville As String, dateEmb As Date,
                   nbRefus As Integer)
        MyBase.New(id, nom, prenom, login, adresse, cp, ville, dateEmb)
        Me.NbFichesRefusees = nbRefus
    End Sub

    Public Overrides ReadOnly Property TypeUtilisateur As String
        Get
            Return "Comptable"
        End Get
    End Property

    Public Overrides Function ToString() As String
        Return MyBase.ToString() & " — " & NbFichesRefusees & " refus"
    End Function

End Class
