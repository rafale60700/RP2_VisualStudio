﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReinitialisationMDP
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnActualiser = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnActualiser
        '
        Me.btnActualiser.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnActualiser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnActualiser.FlatAppearance.BorderSize = 0
        Me.btnActualiser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnActualiser.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnActualiser.ForeColor = System.Drawing.Color.White
        Me.btnActualiser.Location = New System.Drawing.Point(296, 344)
        Me.btnActualiser.Name = "btnActualiser"
        Me.btnActualiser.Size = New System.Drawing.Size(130, 36)
        Me.btnActualiser.TabIndex = 1
        Me.btnActualiser.Text = "Actualiser"
        Me.btnActualiser.UseVisualStyleBackColor = False
        '
        'ReinitialisationMDP
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnActualiser)
        Me.Name = "ReinitialisationMDP"
        Me.Text = "ReinitialisationMDP"
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents btnActualiser As Button
End Class
