﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmReinitialisationMDP
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlBandeau = New System.Windows.Forms.Panel()
        Me.lblTitre = New System.Windows.Forms.Label()
        Me.lblSousTitre = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.pnlMenu = New System.Windows.Forms.Panel()
        Me.txtConfirmMDP = New System.Windows.Forms.TextBox()
        Me.txtNouvMDP = New System.Windows.Forms.TextBox()
        Me.btnAnnuler = New System.Windows.Forms.Button()
        Me.btnReinitMDP = New System.Windows.Forms.Button()
        Me.cboUtilisateur = New System.Windows.Forms.ComboBox()
        Me.lblConfirmMDP = New System.Windows.Forms.Label()
        Me.lblNouvMDP = New System.Windows.Forms.Label()
        Me.lblNomUtil = New System.Windows.Forms.Label()
        Me.btnRetour = New System.Windows.Forms.Button()
        Me.pnlBandeau.SuspendLayout()
        Me.pnlMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBandeau
        '
        Me.pnlBandeau.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.pnlBandeau.Controls.Add(Me.lblTitre)
        Me.pnlBandeau.Controls.Add(Me.lblSousTitre)
        Me.pnlBandeau.Location = New System.Drawing.Point(-50, -1)
        Me.pnlBandeau.Name = "pnlBandeau"
        Me.pnlBandeau.Size = New System.Drawing.Size(984, 90)
        Me.pnlBandeau.TabIndex = 2
        '
        'lblTitre
        '
        Me.lblTitre.AutoSize = True
        Me.lblTitre.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitre.ForeColor = System.Drawing.Color.White
        Me.lblTitre.Location = New System.Drawing.Point(62, 10)
        Me.lblTitre.Name = "lblTitre"
        Me.lblTitre.Size = New System.Drawing.Size(338, 30)
        Me.lblTitre.TabIndex = 0
        Me.lblTitre.Text = "Réinitialiser votre mot de passe"
        '
        'lblSousTitre
        '
        Me.lblSousTitre.AutoSize = True
        Me.lblSousTitre.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblSousTitre.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblSousTitre.Location = New System.Drawing.Point(64, 49)
        Me.lblSousTitre.Name = "lblSousTitre"
        Me.lblSousTitre.Size = New System.Drawing.Size(387, 15)
        Me.lblSousTitre.TabIndex = 1
        Me.lblSousTitre.Text = "Sélectionnez votre nom d'utilisateur pour réinitialiser votre mot de passe"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'pnlMenu
        '
        Me.pnlMenu.BackColor = System.Drawing.Color.White
        Me.pnlMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlMenu.Controls.Add(Me.txtConfirmMDP)
        Me.pnlMenu.Controls.Add(Me.txtNouvMDP)
        Me.pnlMenu.Controls.Add(Me.btnAnnuler)
        Me.pnlMenu.Controls.Add(Me.btnReinitMDP)
        Me.pnlMenu.Controls.Add(Me.cboUtilisateur)
        Me.pnlMenu.Controls.Add(Me.lblConfirmMDP)
        Me.pnlMenu.Controls.Add(Me.lblNouvMDP)
        Me.pnlMenu.Controls.Add(Me.lblNomUtil)
        Me.pnlMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.pnlMenu.Location = New System.Drawing.Point(59, 163)
        Me.pnlMenu.Name = "pnlMenu"
        Me.pnlMenu.Size = New System.Drawing.Size(352, 383)
        Me.pnlMenu.TabIndex = 6
        '
        'txtConfirmMDP
        '
        Me.txtConfirmMDP.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtConfirmMDP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtConfirmMDP.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtConfirmMDP.Location = New System.Drawing.Point(22, 229)
        Me.txtConfirmMDP.MaxLength = 50
        Me.txtConfirmMDP.Name = "txtConfirmMDP"
        Me.txtConfirmMDP.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConfirmMDP.Size = New System.Drawing.Size(300, 25)
        Me.txtConfirmMDP.TabIndex = 13
        Me.txtConfirmMDP.UseSystemPasswordChar = True
        '
        'txtNouvMDP
        '
        Me.txtNouvMDP.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtNouvMDP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNouvMDP.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtNouvMDP.Location = New System.Drawing.Point(22, 137)
        Me.txtNouvMDP.MaxLength = 50
        Me.txtNouvMDP.Name = "txtNouvMDP"
        Me.txtNouvMDP.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtNouvMDP.Size = New System.Drawing.Size(300, 25)
        Me.txtNouvMDP.TabIndex = 12
        Me.txtNouvMDP.UseSystemPasswordChar = True
        '
        'btnAnnuler
        '
        Me.btnAnnuler.BackColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnAnnuler.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAnnuler.FlatAppearance.BorderSize = 0
        Me.btnAnnuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAnnuler.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnAnnuler.ForeColor = System.Drawing.Color.White
        Me.btnAnnuler.Location = New System.Drawing.Point(179, 298)
        Me.btnAnnuler.Name = "btnAnnuler"
        Me.btnAnnuler.Size = New System.Drawing.Size(143, 45)
        Me.btnAnnuler.TabIndex = 11
        Me.btnAnnuler.Text = "Annuler"
        Me.btnAnnuler.UseVisualStyleBackColor = False
        '
        'btnReinitMDP
        '
        Me.btnReinitMDP.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnReinitMDP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReinitMDP.FlatAppearance.BorderSize = 0
        Me.btnReinitMDP.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReinitMDP.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnReinitMDP.ForeColor = System.Drawing.Color.White
        Me.btnReinitMDP.Location = New System.Drawing.Point(22, 298)
        Me.btnReinitMDP.Name = "btnReinitMDP"
        Me.btnReinitMDP.Size = New System.Drawing.Size(136, 45)
        Me.btnReinitMDP.TabIndex = 10
        Me.btnReinitMDP.Text = "Réinitialiser"
        Me.btnReinitMDP.UseVisualStyleBackColor = False
        '
        'cboUtilisateur
        '
        Me.cboUtilisateur.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboUtilisateur.FormattingEnabled = True
        Me.cboUtilisateur.Location = New System.Drawing.Point(22, 60)
        Me.cboUtilisateur.Name = "cboUtilisateur"
        Me.cboUtilisateur.Size = New System.Drawing.Size(300, 24)
        Me.cboUtilisateur.TabIndex = 9
        '
        'lblConfirmMDP
        '
        Me.lblConfirmMDP.AutoSize = True
        Me.lblConfirmMDP.BackColor = System.Drawing.Color.Transparent
        Me.lblConfirmMDP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblConfirmMDP.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblConfirmMDP.Location = New System.Drawing.Point(19, 192)
        Me.lblConfirmMDP.Name = "lblConfirmMDP"
        Me.lblConfirmMDP.Size = New System.Drawing.Size(146, 15)
        Me.lblConfirmMDP.TabIndex = 8
        Me.lblConfirmMDP.Text = "Confirmer mot de passe :"
        '
        'lblNouvMDP
        '
        Me.lblNouvMDP.AutoSize = True
        Me.lblNouvMDP.BackColor = System.Drawing.Color.Transparent
        Me.lblNouvMDP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNouvMDP.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblNouvMDP.Location = New System.Drawing.Point(19, 107)
        Me.lblNouvMDP.Name = "lblNouvMDP"
        Me.lblNouvMDP.Size = New System.Drawing.Size(139, 15)
        Me.lblNouvMDP.TabIndex = 7
        Me.lblNouvMDP.Text = "Nouveau mot de passe :"
        '
        'lblNomUtil
        '
        Me.lblNomUtil.AutoSize = True
        Me.lblNomUtil.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblNomUtil.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNomUtil.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblNomUtil.Location = New System.Drawing.Point(19, 33)
        Me.lblNomUtil.Name = "lblNomUtil"
        Me.lblNomUtil.Size = New System.Drawing.Size(71, 15)
        Me.lblNomUtil.TabIndex = 6
        Me.lblNomUtil.Text = "Utilisateur :"
        '
        'btnRetour
        '
        Me.btnRetour.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.btnRetour.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRetour.FlatAppearance.BorderSize = 0
        Me.btnRetour.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRetour.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnRetour.ForeColor = System.Drawing.Color.White
        Me.btnRetour.Location = New System.Drawing.Point(310, 104)
        Me.btnRetour.Name = "btnRetour"
        Me.btnRetour.Size = New System.Drawing.Size(150, 36)
        Me.btnRetour.TabIndex = 30
        Me.btnRetour.Text = "← Retour au menu"
        Me.btnRetour.UseVisualStyleBackColor = False
        '
        'FrmReinitialisationMDP
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(472, 558)
        Me.Controls.Add(Me.btnRetour)
        Me.Controls.Add(Me.pnlMenu)
        Me.Controls.Add(Me.pnlBandeau)
        Me.Name = "FrmReinitialisationMDP"
        Me.Text = "FrmReinitialisationMDP"
        Me.pnlBandeau.ResumeLayout(False)
        Me.pnlBandeau.PerformLayout()
        Me.pnlMenu.ResumeLayout(False)
        Me.pnlMenu.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents pnlBandeau As Panel
    Private WithEvents lblTitre As Label
    Private WithEvents lblSousTitre As Label
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Private WithEvents pnlMenu As Panel
    Friend WithEvents lblConfirmMDP As Label
    Friend WithEvents lblNouvMDP As Label
    Friend WithEvents lblNomUtil As Label
    Friend WithEvents cboUtilisateur As ComboBox
    Private WithEvents btnAnnuler As Button
    Private WithEvents btnReinitMDP As Button
    Private WithEvents txtNouvMDP As TextBox
    Private WithEvents txtConfirmMDP As TextBox
    Private WithEvents btnRetour As Button
End Class
