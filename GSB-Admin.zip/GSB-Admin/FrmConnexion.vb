' ============================================================
' FrmConnexion.vb — Formulaire de connexion super-admin
' GSB-Admin — BTS SIO
' Conforme CDC AP8 : authentification par mot de passe uniquement
' ============================================================

Imports System.Windows.Forms
Imports System.Drawing

Public Class FrmConnexion
    Inherits Form

    ' ── Déclaration des contrôles ────────────────────────────
    Private WithEvents btnConnexion As Button
    Private txtMdp As TextBox
    Private lblErreur As Label
    Private lblTitre As Label
    Private lblSousTitre As Label
    Private lblMdp As Label
    Private pnlBandeau As Panel
    Private pnlFormulaire As Panel

    ' ── Constructeur ─────────────────────────────────────────
    Public Sub New()
        InitializeComponent()
    End Sub

    ' ── Initialisation visuelle ───────────────────────────────
    Private Sub InitializeComponent()
        Me.pnlBandeau = New System.Windows.Forms.Panel()
        Me.lblTitre = New System.Windows.Forms.Label()
        Me.lblSousTitre = New System.Windows.Forms.Label()
        Me.pnlFormulaire = New System.Windows.Forms.Panel()
        Me.lblMdp = New System.Windows.Forms.Label()
        Me.txtMdp = New System.Windows.Forms.TextBox()
        Me.lblErreur = New System.Windows.Forms.Label()
        Me.btnConnexion = New System.Windows.Forms.Button()
        Me.pnlBandeau.SuspendLayout()
        Me.pnlFormulaire.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBandeau
        '
        Me.pnlBandeau.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.pnlBandeau.Controls.Add(Me.lblTitre)
        Me.pnlBandeau.Controls.Add(Me.lblSousTitre)
        Me.pnlBandeau.Location = New System.Drawing.Point(0, 0)
        Me.pnlBandeau.Name = "pnlBandeau"
        Me.pnlBandeau.Size = New System.Drawing.Size(420, 110)
        Me.pnlBandeau.TabIndex = 0
        '
        'lblTitre
        '
        Me.lblTitre.AutoSize = True
        Me.lblTitre.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitre.ForeColor = System.Drawing.Color.White
        Me.lblTitre.Location = New System.Drawing.Point(30, 22)
        Me.lblTitre.Name = "lblTitre"
        Me.lblTitre.Size = New System.Drawing.Size(164, 37)
        Me.lblTitre.TabIndex = 0
        Me.lblTitre.Text = "GSB-Admin"
        '
        'lblSousTitre
        '
        Me.lblSousTitre.AutoSize = True
        Me.lblSousTitre.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lblSousTitre.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblSousTitre.Location = New System.Drawing.Point(32, 66)
        Me.lblSousTitre.Name = "lblSousTitre"
        Me.lblSousTitre.Size = New System.Drawing.Size(166, 19)
        Me.lblSousTitre.TabIndex = 1
        Me.lblSousTitre.Text = "Application de back-office"
        '
        'pnlFormulaire
        '
        Me.pnlFormulaire.BackColor = System.Drawing.Color.White
        Me.pnlFormulaire.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFormulaire.Controls.Add(Me.lblMdp)
        Me.pnlFormulaire.Controls.Add(Me.txtMdp)
        Me.pnlFormulaire.Controls.Add(Me.lblErreur)
        Me.pnlFormulaire.Controls.Add(Me.btnConnexion)
        Me.pnlFormulaire.Location = New System.Drawing.Point(40, 140)
        Me.pnlFormulaire.Name = "pnlFormulaire"
        Me.pnlFormulaire.Size = New System.Drawing.Size(340, 180)
        Me.pnlFormulaire.TabIndex = 1
        '
        'lblMdp
        '
        Me.lblMdp.AutoSize = True
        Me.lblMdp.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblMdp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblMdp.Location = New System.Drawing.Point(20, 24)
        Me.lblMdp.Name = "lblMdp"
        Me.lblMdp.Size = New System.Drawing.Size(165, 15)
        Me.lblMdp.TabIndex = 0
        Me.lblMdp.Text = "Mot de passe administrateur"
        '
        'txtMdp
        '
        Me.txtMdp.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtMdp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMdp.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtMdp.Location = New System.Drawing.Point(20, 46)
        Me.txtMdp.MaxLength = 50
        Me.txtMdp.Name = "txtMdp"
        Me.txtMdp.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtMdp.Size = New System.Drawing.Size(300, 25)
        Me.txtMdp.TabIndex = 1
        '
        'lblErreur
        '
        Me.lblErreur.AutoSize = True
        Me.lblErreur.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblErreur.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.lblErreur.Location = New System.Drawing.Point(20, 86)
        Me.lblErreur.Name = "lblErreur"
        Me.lblErreur.Size = New System.Drawing.Size(130, 15)
        Me.lblErreur.TabIndex = 2
        Me.lblErreur.Text = "Mot de passe incorrect."
        Me.lblErreur.Visible = False
        '
        'btnConnexion
        '
        Me.btnConnexion.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnConnexion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnConnexion.FlatAppearance.BorderSize = 0
        Me.btnConnexion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConnexion.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnConnexion.ForeColor = System.Drawing.Color.White
        Me.btnConnexion.Location = New System.Drawing.Point(20, 122)
        Me.btnConnexion.Name = "btnConnexion"
        Me.btnConnexion.Size = New System.Drawing.Size(300, 40)
        Me.btnConnexion.TabIndex = 3
        Me.btnConnexion.Text = "Se connecter"
        Me.btnConnexion.UseVisualStyleBackColor = False
        '
        'FrmConnexion
        '
        Me.AcceptButton = Me.btnConnexion
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(404, 361)
        Me.Controls.Add(Me.pnlBandeau)
        Me.Controls.Add(Me.pnlFormulaire)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrmConnexion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Connexion"
        Me.pnlBandeau.ResumeLayout(False)
        Me.pnlBandeau.PerformLayout()
        Me.pnlFormulaire.ResumeLayout(False)
        Me.pnlFormulaire.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    ' ── Chargement : lecture du fichier INI ──────────────────
    Private Sub FrmConnexion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ModConfig.Charger()
        Catch ex As Exception
            MessageBox.Show(
                ex.Message,
                "Erreur de configuration",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)
            Application.Exit()
        End Try
        txtMdp.Focus()
    End Sub

    ' ── Clic sur "Se connecter" ───────────────────────────────
    Private Sub btnConnexion_Click(sender As Object, e As EventArgs) Handles btnConnexion.Click
        Dim mdpSaisi As String = txtMdp.Text

        ' Champ vide
        If mdpSaisi.Trim() = String.Empty Then
            AfficherErreur("Veuillez saisir le mot de passe.")
            Return
        End If

        ' Vérification mot de passe via hash SHA-256
        If Not ModConfig.VerifierMotDePasse(mdpSaisi) Then
            AfficherErreur("Mot de passe incorrect.")
            Return
        End If

        ' Connexion réussie → ouvrir le menu principal
        Dim frmMenu As New FrmMenu()
        frmMenu.Show()
        Me.Hide()
    End Sub

    ' ── Affiche un message d'erreur ──────────────────────────
    Private Sub AfficherErreur(message As String)
        lblErreur.Text = message
        lblErreur.Visible = True
        txtMdp.Clear()
        txtMdp.Focus()
    End Sub

End Class