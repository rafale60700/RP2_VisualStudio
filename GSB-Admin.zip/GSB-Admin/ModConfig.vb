' ============================================================
' Module ModConfig.vb
' Lecture du fichier de configuration GSB-Admin (gsb.ini)
' ============================================================
' Utilisation :
'   ModConfig.Charger()           ' à appeler au démarrage (Program.vb)
'   ModConfig.DbConnectionString  ' chaîne de connexion MySQL
'   ModConfig.AdminLogin          ' login super-admin
'   ModConfig.AdminPasswordHash   ' hash SHA-256 du mot de passe admin
' ============================================================

Imports System.IO
Imports System.Text
Imports System.Security.Cryptography

Module ModConfig

    ' --------------------------------------------------------
    ' Propriétés publiques accessibles depuis toute l'appli
    ' --------------------------------------------------------
    Public DbConnectionString As String = String.Empty
    Public AdminLogin          As String = String.Empty
    Public AdminPasswordHash   As String = String.Empty

    ' Nom du fichier INI — placé à côté de l'exécutable
    Private Const NOM_FICHIER As String = "gsb.ini"

    ' --------------------------------------------------------
    ' Chargement du fichier INI
    ' À appeler UNE SEULE FOIS au démarrage dans Program.vb
    ' --------------------------------------------------------
    Public Sub Charger()
        ' Recherche du fichier : d'abord à côté de l'exe, sinon chemin absolu
        Dim cheminFichier As String = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, NOM_FICHIER)

        If Not File.Exists(cheminFichier) Then
            Throw New FileNotFoundException(
                "Fichier de configuration introuvable : " & cheminFichier & vbCrLf &
                "Créez le fichier gsb.ini à côté de l'application.")
        End If

        ' Lecture de toutes les lignes (ignore les commentaires et lignes vides)
        Dim section As String = String.Empty
        Dim valeurs As New Dictionary(Of String, Dictionary(Of String, String))

        For Each ligne As String In File.ReadAllLines(cheminFichier, Encoding.UTF8)
            Dim l As String = ligne.Trim()

            ' Ignorer commentaires et lignes vides
            If l.Length = 0 OrElse l.StartsWith(";") OrElse l.StartsWith("#") Then
                Continue For
            End If

            ' Détection d'une section [nom]
            If l.StartsWith("[") AndAlso l.EndsWith("]") Then
                section = l.Substring(1, l.Length - 2).ToLower().Trim()
                If Not valeurs.ContainsKey(section) Then
                    valeurs(section) = New Dictionary(Of String, String)
                End If
                Continue For
            End If

            ' Lecture d'une clé = valeur
            Dim separateur As Integer = l.IndexOf("=")
            If separateur > 0 AndAlso section <> String.Empty Then
                Dim cle   As String = l.Substring(0, separateur).Trim().ToLower()
                Dim valeur As String = l.Substring(separateur + 1).Trim()
                ' Supprimer les commentaires inline (après ;)
                Dim posCommentaire As Integer = valeur.IndexOf(" ;")
                If posCommentaire > 0 Then
                    valeur = valeur.Substring(0, posCommentaire).Trim()
                End If
                valeurs(section)(cle) = valeur
            End If
        Next

        ' --------------------------------------------------------
        ' Construction de la chaîne de connexion MySQL
        ' Nécessite le connecteur : MySql.Data (NuGet)
        ' --------------------------------------------------------
        Try
            Dim db As Dictionary(Of String, String) = valeurs("database")
            DbConnectionString = String.Format(
                "Server={0};Port={1};Database={2};Uid={3};Pwd={4};CharSet=utf8;",
                db("server"),
                db("port"),
                db("name"),
                db("user"),
                db("password"))
        Catch ex As Exception
            Throw New Exception("Section [database] manquante ou incomplète dans gsb.ini." & vbCrLf & ex.Message)
        End Try

        ' --------------------------------------------------------
        ' Récupération des identifiants super-admin
        ' --------------------------------------------------------
        Try
            Dim sa As Dictionary(Of String, String) = valeurs("superadmin")
            AdminLogin        = sa("login")
            AdminPasswordHash = sa("password").ToLower()
        Catch ex As Exception
            Throw New Exception("Section [superadmin] manquante ou incomplète dans gsb.ini." & vbCrLf & ex.Message)
        End Try

    End Sub

    ' --------------------------------------------------------
    ' Vérifie le mot de passe super-admin saisi par l'utilisateur
    ' Retourne True si le hash correspond
    ' --------------------------------------------------------
    Public Function VerifierMotDePasse(motDePasseSaisi As String) As Boolean
        Dim hash As String = HashSHA256(motDePasseSaisi)
        Return String.Equals(hash, AdminPasswordHash, StringComparison.OrdinalIgnoreCase)
    End Function

    ' --------------------------------------------------------
    ' Calcule le hash SHA-256 d'une chaîne (en minuscules)
    ' --------------------------------------------------------
    Private Function HashSHA256(texte As String) As String
        Using sha As SHA256 = SHA256.Create()
            Dim octets() As Byte = sha.ComputeHash(Encoding.UTF8.GetBytes(texte))
            Dim sb As New StringBuilder()
            For Each b As Byte In octets
                sb.Append(b.ToString("x2"))
            Next
            Return sb.ToString()
        End Using
    End Function

End Module
