' ============================================================
' FrmReinitialiseMdp.vb — Réinitialisation du mot de passe
' GSB-Admin — BTS SIO
' ============================================================

Imports System.Windows.Forms
Imports System.Drawing
Imports MySql.Data.MySqlClient

Public Class FrmReinitialiseMdp
    Inherits Form

    ' ── Déclaration des contrôles ────────────────────────────
    Private pnlBandeau As Panel
    Private lblTitre As Label
    Private lblSousTitre As Label
    Private pnlFormulaire As Panel
    Private lblRecherche As Label
    Private txtRecherche As TextBox
    Private WithEvents btnRechercher As Button
    Private lblResultat As Label
    Private WithEvents dgvUtilisateurs As DataGridView
    Private lblNouveauMdp As Label
    Private txtNouveauMdp As TextBox
    Private lblConfirmMdp As Label
    Private txtConfirmMdp As TextBox
    Private lblErreur As Label
    Private lblSucces As Label
    Private WithEvents btnReinitialiser As Button
    Private pnlBas As Panel
    Private WithEvents btnRetour As Button

    ' ── Constructeur ─────────────────────────────────────────
    Public Sub New()
        InitializeComponent()
    End Sub

    ' ── Initialisation visuelle ───────────────────────────────
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlBandeau = New System.Windows.Forms.Panel()
        Me.lblTitre = New System.Windows.Forms.Label()
        Me.lblSousTitre = New System.Windows.Forms.Label()
        Me.pnlFormulaire = New System.Windows.Forms.Panel()
        Me.lblRecherche = New System.Windows.Forms.Label()
        Me.txtRecherche = New System.Windows.Forms.TextBox()
        Me.btnRechercher = New System.Windows.Forms.Button()
        Me.lblResultat = New System.Windows.Forms.Label()
        Me.dgvUtilisateurs = New System.Windows.Forms.DataGridView()
        Me.lblNouveauMdp = New System.Windows.Forms.Label()
        Me.txtNouveauMdp = New System.Windows.Forms.TextBox()
        Me.lblConfirmMdp = New System.Windows.Forms.Label()
        Me.txtConfirmMdp = New System.Windows.Forms.TextBox()
        Me.lblErreur = New System.Windows.Forms.Label()
        Me.lblSucces = New System.Windows.Forms.Label()
        Me.btnReinitialiser = New System.Windows.Forms.Button()
        Me.pnlBas = New System.Windows.Forms.Panel()
        Me.btnRetour = New System.Windows.Forms.Button()
        Me.pnlBandeau.SuspendLayout()
        Me.pnlFormulaire.SuspendLayout()
        CType(Me.dgvUtilisateurs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlBas.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBandeau
        '
        Me.pnlBandeau.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.pnlBandeau.Controls.Add(Me.lblTitre)
        Me.pnlBandeau.Controls.Add(Me.lblSousTitre)
        Me.pnlBandeau.Location = New System.Drawing.Point(0, 0)
        Me.pnlBandeau.Name = "pnlBandeau"
        Me.pnlBandeau.Size = New System.Drawing.Size(800, 80)
        Me.pnlBandeau.TabIndex = 0
        '
        'lblTitre
        '
        Me.lblTitre.AutoSize = True
        Me.lblTitre.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitre.ForeColor = System.Drawing.Color.White
        Me.lblTitre.Location = New System.Drawing.Point(30, 15)
        Me.lblTitre.Name = "lblTitre"
        Me.lblTitre.Size = New System.Drawing.Size(316, 28)
        Me.lblTitre.TabIndex = 0
        Me.lblTitre.Text = "Réinitialisation du mot de passe"
        '
        'lblSousTitre
        '
        Me.lblSousTitre.AutoSize = True
        Me.lblSousTitre.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblSousTitre.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblSousTitre.Location = New System.Drawing.Point(32, 48)
        Me.lblSousTitre.Name = "lblSousTitre"
        Me.lblSousTitre.Size = New System.Drawing.Size(362, 15)
        Me.lblSousTitre.TabIndex = 1
        Me.lblSousTitre.Text = "Recherchez un utilisateur puis définissez son nouveau mot de passe"
        '
        'pnlFormulaire
        '
        Me.pnlFormulaire.BackColor = System.Drawing.Color.White
        Me.pnlFormulaire.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFormulaire.Controls.Add(Me.lblRecherche)
        Me.pnlFormulaire.Controls.Add(Me.txtRecherche)
        Me.pnlFormulaire.Controls.Add(Me.btnRechercher)
        Me.pnlFormulaire.Controls.Add(Me.lblResultat)
        Me.pnlFormulaire.Controls.Add(Me.dgvUtilisateurs)
        Me.pnlFormulaire.Controls.Add(Me.lblNouveauMdp)
        Me.pnlFormulaire.Controls.Add(Me.txtNouveauMdp)
        Me.pnlFormulaire.Controls.Add(Me.lblConfirmMdp)
        Me.pnlFormulaire.Controls.Add(Me.txtConfirmMdp)
        Me.pnlFormulaire.Controls.Add(Me.lblErreur)
        Me.pnlFormulaire.Controls.Add(Me.lblSucces)
        Me.pnlFormulaire.Controls.Add(Me.btnReinitialiser)
        Me.pnlFormulaire.Location = New System.Drawing.Point(30, 100)
        Me.pnlFormulaire.Name = "pnlFormulaire"
        Me.pnlFormulaire.Size = New System.Drawing.Size(740, 480)
        Me.pnlFormulaire.TabIndex = 1
        '
        'lblRecherche
        '
        Me.lblRecherche.AutoSize = True
        Me.lblRecherche.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRecherche.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.lblRecherche.Location = New System.Drawing.Point(20, 18)
        Me.lblRecherche.Name = "lblRecherche"
        Me.lblRecherche.Size = New System.Drawing.Size(281, 15)
        Me.lblRecherche.TabIndex = 0
        Me.lblRecherche.Text = "Rechercher un utilisateur (nom, prénom ou login)"
        '
        'txtRecherche
        '
        Me.txtRecherche.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtRecherche.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRecherche.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtRecherche.Location = New System.Drawing.Point(20, 40)
        Me.txtRecherche.MaxLength = 50
        Me.txtRecherche.Name = "txtRecherche"
        Me.txtRecherche.Size = New System.Drawing.Size(500, 25)
        Me.txtRecherche.TabIndex = 1
        '
        'btnRechercher
        '
        Me.btnRechercher.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnRechercher.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRechercher.FlatAppearance.BorderSize = 0
        Me.btnRechercher.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRechercher.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnRechercher.ForeColor = System.Drawing.Color.White
        Me.btnRechercher.Location = New System.Drawing.Point(530, 40)
        Me.btnRechercher.Name = "btnRechercher"
        Me.btnRechercher.Size = New System.Drawing.Size(120, 28)
        Me.btnRechercher.TabIndex = 2
        Me.btnRechercher.Text = "Rechercher"
        Me.btnRechercher.UseVisualStyleBackColor = False
        '
        'lblResultat
        '
        Me.lblResultat.AutoSize = True
        Me.lblResultat.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblResultat.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblResultat.Location = New System.Drawing.Point(20, 82)
        Me.lblResultat.Name = "lblResultat"
        Me.lblResultat.Size = New System.Drawing.Size(0, 15)
        Me.lblResultat.TabIndex = 3
        Me.lblResultat.Visible = False
        '
        'dgvUtilisateurs
        '
        Me.dgvUtilisateurs.AllowUserToAddRows = False
        Me.dgvUtilisateurs.AllowUserToDeleteRows = False
        Me.dgvUtilisateurs.AllowUserToResizeRows = False
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.dgvUtilisateurs.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.dgvUtilisateurs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvUtilisateurs.BackgroundColor = System.Drawing.Color.White
        Me.dgvUtilisateurs.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Segoe UI", 9.5!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvUtilisateurs.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.dgvUtilisateurs.ColumnHeadersHeight = 34
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvUtilisateurs.DefaultCellStyle = DataGridViewCellStyle9
        Me.dgvUtilisateurs.EnableHeadersVisualStyles = False
        Me.dgvUtilisateurs.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.dgvUtilisateurs.Location = New System.Drawing.Point(20, 100)
        Me.dgvUtilisateurs.MultiSelect = False
        Me.dgvUtilisateurs.Name = "dgvUtilisateurs"
        Me.dgvUtilisateurs.ReadOnly = True
        Me.dgvUtilisateurs.RowHeadersVisible = False
        Me.dgvUtilisateurs.RowTemplate.Height = 28
        Me.dgvUtilisateurs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvUtilisateurs.Size = New System.Drawing.Size(700, 150)
        Me.dgvUtilisateurs.TabIndex = 4
        Me.dgvUtilisateurs.Visible = False
        '
        'lblNouveauMdp
        '
        Me.lblNouveauMdp.AutoSize = True
        Me.lblNouveauMdp.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblNouveauMdp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.lblNouveauMdp.Location = New System.Drawing.Point(20, 268)
        Me.lblNouveauMdp.Name = "lblNouveauMdp"
        Me.lblNouveauMdp.Size = New System.Drawing.Size(133, 15)
        Me.lblNouveauMdp.TabIndex = 5
        Me.lblNouveauMdp.Text = "Nouveau mot de passe"
        Me.lblNouveauMdp.Visible = False
        '
        'txtNouveauMdp
        '
        Me.txtNouveauMdp.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtNouveauMdp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNouveauMdp.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtNouveauMdp.Location = New System.Drawing.Point(20, 290)
        Me.txtNouveauMdp.MaxLength = 50
        Me.txtNouveauMdp.Name = "txtNouveauMdp"
        Me.txtNouveauMdp.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtNouveauMdp.Size = New System.Drawing.Size(330, 25)
        Me.txtNouveauMdp.TabIndex = 6
        Me.txtNouveauMdp.Visible = False
        '
        'lblConfirmMdp
        '
        Me.lblConfirmMdp.AutoSize = True
        Me.lblConfirmMdp.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblConfirmMdp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.lblConfirmMdp.Location = New System.Drawing.Point(370, 268)
        Me.lblConfirmMdp.Name = "lblConfirmMdp"
        Me.lblConfirmMdp.Size = New System.Drawing.Size(153, 15)
        Me.lblConfirmMdp.TabIndex = 7
        Me.lblConfirmMdp.Text = "Confirmer le mot de passe"
        Me.lblConfirmMdp.Visible = False
        '
        'txtConfirmMdp
        '
        Me.txtConfirmMdp.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.txtConfirmMdp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtConfirmMdp.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtConfirmMdp.Location = New System.Drawing.Point(370, 290)
        Me.txtConfirmMdp.MaxLength = 50
        Me.txtConfirmMdp.Name = "txtConfirmMdp"
        Me.txtConfirmMdp.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConfirmMdp.Size = New System.Drawing.Size(330, 25)
        Me.txtConfirmMdp.TabIndex = 8
        Me.txtConfirmMdp.Visible = False
        '
        'lblErreur
        '
        Me.lblErreur.AutoSize = True
        Me.lblErreur.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblErreur.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.lblErreur.Location = New System.Drawing.Point(20, 334)
        Me.lblErreur.Name = "lblErreur"
        Me.lblErreur.Size = New System.Drawing.Size(0, 15)
        Me.lblErreur.TabIndex = 9
        Me.lblErreur.Visible = False
        '
        'lblSucces
        '
        Me.lblSucces.AutoSize = True
        Me.lblSucces.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblSucces.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.lblSucces.Location = New System.Drawing.Point(20, 334)
        Me.lblSucces.Name = "lblSucces"
        Me.lblSucces.Size = New System.Drawing.Size(0, 15)
        Me.lblSucces.TabIndex = 10
        Me.lblSucces.Visible = False
        '
        'btnReinitialiser
        '
        Me.btnReinitialiser.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.btnReinitialiser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReinitialiser.FlatAppearance.BorderSize = 0
        Me.btnReinitialiser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReinitialiser.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnReinitialiser.ForeColor = System.Drawing.Color.White
        Me.btnReinitialiser.Location = New System.Drawing.Point(20, 378)
        Me.btnReinitialiser.Name = "btnReinitialiser"
        Me.btnReinitialiser.Size = New System.Drawing.Size(260, 38)
        Me.btnReinitialiser.TabIndex = 11
        Me.btnReinitialiser.Text = "Réinitialiser le mot de passe"
        Me.btnReinitialiser.UseVisualStyleBackColor = False
        Me.btnReinitialiser.Visible = False
        '
        'pnlBas
        '
        Me.pnlBas.BackColor = System.Drawing.Color.White
        Me.pnlBas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlBas.Controls.Add(Me.btnRetour)
        Me.pnlBas.Location = New System.Drawing.Point(30, 586)
        Me.pnlBas.Name = "pnlBas"
        Me.pnlBas.Size = New System.Drawing.Size(740, 46)
        Me.pnlBas.TabIndex = 2
        '
        'btnRetour
        '
        Me.btnRetour.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.btnRetour.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRetour.FlatAppearance.BorderSize = 0
        Me.btnRetour.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRetour.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.btnRetour.ForeColor = System.Drawing.Color.White
        Me.btnRetour.Location = New System.Drawing.Point(566, 8)
        Me.btnRetour.Name = "btnRetour"
        Me.btnRetour.Size = New System.Drawing.Size(160, 30)
        Me.btnRetour.TabIndex = 0
        Me.btnRetour.Text = "← Retour au menu"
        Me.btnRetour.UseVisualStyleBackColor = False
        '
        'FrmReinitialiseMdp
        '
        Me.AcceptButton = Me.btnRechercher
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(784, 643)
        Me.Controls.Add(Me.pnlBandeau)
        Me.Controls.Add(Me.pnlFormulaire)
        Me.Controls.Add(Me.pnlBas)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrmReinitialiseMdp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Réinitialisation du mot de passe"
        Me.pnlBandeau.ResumeLayout(False)
        Me.pnlBandeau.PerformLayout()
        Me.pnlFormulaire.ResumeLayout(False)
        Me.pnlFormulaire.PerformLayout()
        CType(Me.dgvUtilisateurs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlBas.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    ' ── Chargement ───────────────────────────────────────────
    Private Sub FrmReinitialiseMdp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtRecherche.Focus()
    End Sub

    ' ── Rechercher ────────────────────────────────────────────
    Private Sub btnRechercher_Click(sender As Object, e As EventArgs) Handles btnRechercher.Click
        MasquerChampsMdp()
        lblErreur.Visible = False
        lblSucces.Visible = False

        Dim recherche As String = txtRecherche.Text.Trim()
        If recherche = String.Empty Then
            AfficherErreur("Veuillez saisir un nom, prénom ou login.")
            Return
        End If

        Try
            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Dim sql As String =
                    "SELECT u.id AS 'ID', u.nom AS 'Nom', u.prenom AS 'Prénom', " &
                    "u.login AS 'Login', " &
                    "CASE WHEN v.id IS NOT NULL THEN 'Visiteur' ELSE 'Comptable' END AS 'Rôle' " &
                    "FROM utilisateur u LEFT JOIN visiteur v ON v.id = u.id " &
                    "WHERE u.nom LIKE @r OR u.prenom LIKE @r OR u.login LIKE @r " &
                    "ORDER BY u.nom, u.prenom"

                Dim cmd As New MySqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@r", "%" & recherche & "%")

                Dim adapter As New MySqlDataAdapter(cmd)
                Dim table As New DataTable()
                adapter.Fill(table)

                If table.Rows.Count = 0 Then
                    AfficherErreur("Aucun utilisateur trouvé.")
                    dgvUtilisateurs.Visible = False
                    lblResultat.Visible = False
                    Return
                End If

                dgvUtilisateurs.DataSource = table
                dgvUtilisateurs.Visible = True
                lblResultat.Text = table.Rows.Count & " utilisateur(s) trouvé(s) — sélectionnez-en un :"
                lblResultat.Visible = True
            End Using
        Catch ex As Exception
            AfficherErreur("Erreur : " & ex.Message)
        End Try
    End Sub

    ' ── Sélection dans le tableau ─────────────────────────────
    Private Sub dgvUtilisateurs_SelectionChanged(sender As Object, e As EventArgs) Handles dgvUtilisateurs.SelectionChanged
        If dgvUtilisateurs.SelectedRows.Count > 0 Then
            AfficherChampsMdp()
            lblErreur.Visible = False
            lblSucces.Visible = False
            txtNouveauMdp.Clear()
            txtConfirmMdp.Clear()
            txtNouveauMdp.Focus()
        End If
    End Sub

    ' ── Réinitialiser ─────────────────────────────────────────
    Private Sub btnReinitialiser_Click(sender As Object, e As EventArgs) Handles btnReinitialiser.Click
        lblErreur.Visible = False
        lblSucces.Visible = False

        If dgvUtilisateurs.SelectedRows.Count = 0 Then
            AfficherErreur("Veuillez sélectionner un utilisateur.")
            Return
        End If

        Dim nouveauMdp As String = txtNouveauMdp.Text
        Dim confirmMdp As String = txtConfirmMdp.Text

        If nouveauMdp = String.Empty Then
            AfficherErreur("Veuillez saisir un nouveau mot de passe.")
            Return
        End If

        If nouveauMdp.Length < 6 Then
            AfficherErreur("Le mot de passe doit contenir au moins 6 caractères.")
            Return
        End If

        If nouveauMdp <> confirmMdp Then
            AfficherErreur("Les deux mots de passe ne correspondent pas.")
            txtConfirmMdp.Clear()
            txtConfirmMdp.Focus()
            Return
        End If

        Dim idUtilisateur As String = dgvUtilisateurs.SelectedRows(0).Cells("ID").Value.ToString()
        Dim nomComplet As String = dgvUtilisateurs.SelectedRows(0).Cells("Nom").Value.ToString() &
                                      " " & dgvUtilisateurs.SelectedRows(0).Cells("Prénom").Value.ToString()

        Dim reponse As DialogResult = MessageBox.Show(
            "Voulez-vous vraiment réinitialiser le mot de passe de " & nomComplet & " ?",
            "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If reponse <> DialogResult.Yes Then Return

        Try
            Using conn As MySqlConnection = ModDatabase.NouvelleConnexion()
                Dim sql As String = "UPDATE utilisateur SET mdp = SHA2(@mdp, 256) WHERE id = @id"
                Dim cmd As New MySqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@mdp", nouveauMdp)
                cmd.Parameters.AddWithValue("@id", idUtilisateur)
                cmd.ExecuteNonQuery()
            End Using

            lblSucces.Text = "Mot de passe de " & nomComplet & " réinitialisé avec succès."
            lblSucces.Visible = True
            txtNouveauMdp.Clear()
            txtConfirmMdp.Clear()

        Catch ex As Exception
            AfficherErreur("Erreur lors de la mise à jour : " & ex.Message)
        End Try
    End Sub

    ' ── Retour ────────────────────────────────────────────────
    Private Sub btnRetour_Click(sender As Object, e As EventArgs) Handles btnRetour.Click
        Me.Close()
    End Sub

    ' ── Helpers ───────────────────────────────────────────────
    Private Sub AfficherErreur(message As String)
        lblSucces.Visible = False
        lblErreur.Text = message
        lblErreur.Visible = True
    End Sub

    Private Sub AfficherChampsMdp()
        lblNouveauMdp.Visible = True
        txtNouveauMdp.Visible = True
        lblConfirmMdp.Visible = True
        txtConfirmMdp.Visible = True
        btnReinitialiser.Visible = True
    End Sub

    Private Sub MasquerChampsMdp()
        lblNouveauMdp.Visible = False
        txtNouveauMdp.Visible = False
        lblConfirmMdp.Visible = False
        txtConfirmMdp.Visible = False
        btnReinitialiser.Visible = False
    End Sub


End Class
