' ============================================================
' FrmMenu.vb — Menu principal GSB-Admin
' BTS SIO
' ============================================================

Imports System.Windows.Forms
Imports System.Drawing

Public Class FrmMenu
    Inherits Form

    ' ── Déclaration des contrôles ────────────────────────────
    Private pnlBandeau As Panel
    Private pnlMenu As Panel
    Private lblTitre As Label
    Private lblSousTitre As Label
    Private lblBienvenue As Label
    Private WithEvents btnListeUtilisateurs As Button
    Private WithEvents btnReinitialiseMdp As Button
    Private WithEvents btnCreerUtilisateur As Button
    Private WithEvents btnDeconnexion As Button

    ' ── Constructeur ─────────────────────────────────────────
    Public Sub New()
        InitializeComponent()
    End Sub

    ' ── Initialisation visuelle ───────────────────────────────
    Private Sub InitializeComponent()
        Me.pnlBandeau = New System.Windows.Forms.Panel()
        Me.lblTitre = New System.Windows.Forms.Label()
        Me.lblSousTitre = New System.Windows.Forms.Label()
        Me.lblBienvenue = New System.Windows.Forms.Label()
        Me.pnlMenu = New System.Windows.Forms.Panel()
        Me.btnListeUtilisateurs = New System.Windows.Forms.Button()
        Me.btnReinitialiseMdp = New System.Windows.Forms.Button()
        Me.btnCreerUtilisateur = New System.Windows.Forms.Button()
        Me.btnDeconnexion = New System.Windows.Forms.Button()
        Me.pnlBandeau.SuspendLayout()
        Me.pnlMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBandeau
        '
        Me.pnlBandeau.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.pnlBandeau.Controls.Add(Me.lblTitre)
        Me.pnlBandeau.Controls.Add(Me.lblSousTitre)
        Me.pnlBandeau.Location = New System.Drawing.Point(0, 0)
        Me.pnlBandeau.Name = "pnlBandeau"
        Me.pnlBandeau.Size = New System.Drawing.Size(520, 110)
        Me.pnlBandeau.TabIndex = 0
        '
        'lblTitre
        '
        Me.lblTitre.AutoSize = True
        Me.lblTitre.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitre.ForeColor = System.Drawing.Color.White
        Me.lblTitre.Location = New System.Drawing.Point(30, 22)
        Me.lblTitre.Name = "lblTitre"
        Me.lblTitre.Size = New System.Drawing.Size(164, 37)
        Me.lblTitre.TabIndex = 0
        Me.lblTitre.Text = "GSB-Admin"
        '
        'lblSousTitre
        '
        Me.lblSousTitre.AutoSize = True
        Me.lblSousTitre.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lblSousTitre.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblSousTitre.Location = New System.Drawing.Point(32, 66)
        Me.lblSousTitre.Name = "lblSousTitre"
        Me.lblSousTitre.Size = New System.Drawing.Size(166, 19)
        Me.lblSousTitre.TabIndex = 1
        Me.lblSousTitre.Text = "Application de back-office"
        '
        'lblBienvenue
        '
        Me.lblBienvenue.AutoSize = True
        Me.lblBienvenue.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold)
        Me.lblBienvenue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.lblBienvenue.Location = New System.Drawing.Point(154, 130)
        Me.lblBienvenue.Name = "lblBienvenue"
        Me.lblBienvenue.Size = New System.Drawing.Size(194, 20)
        Me.lblBienvenue.TabIndex = 1
        Me.lblBienvenue.Text = "Que souhaitez-vous faire ?"
        '
        'pnlMenu
        '
        Me.pnlMenu.BackColor = System.Drawing.Color.White
        Me.pnlMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlMenu.Controls.Add(Me.btnListeUtilisateurs)
        Me.pnlMenu.Controls.Add(Me.btnReinitialiseMdp)
        Me.pnlMenu.Controls.Add(Me.btnCreerUtilisateur)
        Me.pnlMenu.Controls.Add(Me.btnDeconnexion)
        Me.pnlMenu.Location = New System.Drawing.Point(50, 165)
        Me.pnlMenu.Name = "pnlMenu"
        Me.pnlMenu.Size = New System.Drawing.Size(420, 320)
        Me.pnlMenu.TabIndex = 2
        '
        'btnListeUtilisateurs
        '
        Me.btnListeUtilisateurs.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnListeUtilisateurs.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnListeUtilisateurs.FlatAppearance.BorderSize = 0
        Me.btnListeUtilisateurs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnListeUtilisateurs.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnListeUtilisateurs.ForeColor = System.Drawing.Color.White
        Me.btnListeUtilisateurs.Location = New System.Drawing.Point(20, 20)
        Me.btnListeUtilisateurs.Name = "btnListeUtilisateurs"
        Me.btnListeUtilisateurs.Size = New System.Drawing.Size(380, 55)
        Me.btnListeUtilisateurs.TabIndex = 0
        Me.btnListeUtilisateurs.Tag = "liste"
        Me.btnListeUtilisateurs.Text = "   Liste des utilisateurs"
        Me.btnListeUtilisateurs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnListeUtilisateurs.UseVisualStyleBackColor = False
        '
        'btnReinitialiseMdp
        '
        Me.btnReinitialiseMdp.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnReinitialiseMdp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReinitialiseMdp.FlatAppearance.BorderSize = 0
        Me.btnReinitialiseMdp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReinitialiseMdp.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnReinitialiseMdp.ForeColor = System.Drawing.Color.White
        Me.btnReinitialiseMdp.Location = New System.Drawing.Point(20, 95)
        Me.btnReinitialiseMdp.Name = "btnReinitialiseMdp"
        Me.btnReinitialiseMdp.Size = New System.Drawing.Size(380, 55)
        Me.btnReinitialiseMdp.TabIndex = 1
        Me.btnReinitialiseMdp.Tag = "reinit"
        Me.btnReinitialiseMdp.Text = "   Réinitialiser un mot de passe"
        Me.btnReinitialiseMdp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReinitialiseMdp.UseVisualStyleBackColor = False
        '
        'btnCreerUtilisateur
        '
        Me.btnCreerUtilisateur.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(121, Byte), Integer))
        Me.btnCreerUtilisateur.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCreerUtilisateur.FlatAppearance.BorderSize = 0
        Me.btnCreerUtilisateur.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCreerUtilisateur.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnCreerUtilisateur.ForeColor = System.Drawing.Color.White
        Me.btnCreerUtilisateur.Location = New System.Drawing.Point(20, 170)
        Me.btnCreerUtilisateur.Name = "btnCreerUtilisateur"
        Me.btnCreerUtilisateur.Size = New System.Drawing.Size(380, 55)
        Me.btnCreerUtilisateur.TabIndex = 2
        Me.btnCreerUtilisateur.Tag = "creer"
        Me.btnCreerUtilisateur.Text = "   Créer un utilisateur"
        Me.btnCreerUtilisateur.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCreerUtilisateur.UseVisualStyleBackColor = False
        '
        'btnDeconnexion
        '
        Me.btnDeconnexion.BackColor = System.Drawing.Color.FromArgb(CType(CType(160, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btnDeconnexion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDeconnexion.FlatAppearance.BorderSize = 0
        Me.btnDeconnexion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDeconnexion.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnDeconnexion.ForeColor = System.Drawing.Color.White
        Me.btnDeconnexion.Location = New System.Drawing.Point(20, 245)
        Me.btnDeconnexion.Name = "btnDeconnexion"
        Me.btnDeconnexion.Size = New System.Drawing.Size(380, 55)
        Me.btnDeconnexion.TabIndex = 3
        Me.btnDeconnexion.Tag = "deco"
        Me.btnDeconnexion.Text = "   Déconnexion"
        Me.btnDeconnexion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDeconnexion.UseVisualStyleBackColor = False
        '
        'FrmMenu
        '
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(504, 541)
        Me.Controls.Add(Me.pnlBandeau)
        Me.Controls.Add(Me.lblBienvenue)
        Me.Controls.Add(Me.pnlMenu)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrmMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu principal"
        Me.pnlBandeau.ResumeLayout(False)
        Me.pnlBandeau.PerformLayout()
        Me.pnlMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    ' ── Liste des utilisateurs ────────────────────────────────
    Private Sub btnListeUtilisateurs_Click(sender As Object, e As EventArgs) Handles btnListeUtilisateurs.Click
        Dim frm As New FrmListeUtilisateurs()
        frm.Show()
    End Sub

    ' ── Réinitialiser mot de passe ────────────────────────────
    Private Sub btnReinitialiseMdp_Click(sender As Object, e As EventArgs) Handles btnReinitialiseMdp.Click
        Dim frm As New FrmReinitialisationMDP()
        frm.Show()
    End Sub

    ' ── Créer un utilisateur ──────────────────────────────────
    Private Sub btnCreerUtilisateur_Click(sender As Object, e As EventArgs) Handles btnCreerUtilisateur.Click
        Dim frm As New FrmCreerUtilisateur()
        frm.Show()
    End Sub

    ' ── Déconnexion ───────────────────────────────────────────
    Private Sub btnDeconnexion_Click(sender As Object, e As EventArgs) Handles btnDeconnexion.Click
        Dim reponse As DialogResult = MessageBox.Show(
            "Voulez-vous vraiment vous déconnecter ?",
            "Déconnexion",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question)

        If reponse = DialogResult.Yes Then
            Dim frmConnexion As New FrmConnexion()
            frmConnexion.Show()
            Me.Close()
        End If
    End Sub

    Private Sub lblFooter_Click(sender As Object, e As EventArgs)

    End Sub
End Class
